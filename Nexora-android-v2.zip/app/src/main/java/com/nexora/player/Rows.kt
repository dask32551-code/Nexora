package com.nexora.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

sealed class Row {
    class Head(val title: String) : Row()
    class Vid(val v: Video, val group: List<Video>) : Row()
    class Item(val title: String, val sub: String, val click: () -> Unit, val long: (() -> Unit)? = null, val icon: String? = null) : Row()
}

object Thumbs {
    private val cache = LruCache<Long, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, v: Video, iv: ImageView) {
        iv.tag = v.id
        iv.animate().cancel()
        iv.alpha = 1f
        val hit = cache.get(v.id)
        if (hit != null) { iv.setImageBitmap(hit); return }
        iv.setImageDrawable(null)
        pool.execute {
            val bmp: Bitmap? = try {
                if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(v.uri, Size(320, 180), null) else null
            } catch (e: Exception) { null }
            if (bmp != null) {
                cache.put(v.id, bmp)
                main.post {
                    if (iv.tag == v.id) {
                        iv.alpha = 0f
                        iv.setImageBitmap(bmp)
                        iv.animate().alpha(1f).setDuration(220).start()
                    }
                }
            }
        }
    }
}

class HeadVH(val t: TextView) : RecyclerView.ViewHolder(t)
class VidVH(
    root: View, val thumb: ImageView, val dur: TextView, val prog: View,
    val name: TextView, val meta: TextView, val more: View
) : RecyclerView.ViewHolder(root)
class ItemVH(root: View, val icon: ImageView, val title: TextView, val sub: TextView, val chev: ImageView) : RecyclerView.ViewHolder(root)

/** Frame that always keeps a 16:9 shape, whatever width the grid gives it. */
class RatioFrame(ctx: Context) : FrameLayout(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(width * 9 / 16, MeasureSpec.EXACTLY))
    }
}

class RowAdapter(
    private val ctx: Context,
    private val rows: List<Row>,
    private val store: Store,
    private val onPlay: (List<Video>, Int) -> Unit,
    private val onMenu: (Video) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun getItemCount(): Int = rows.size

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Head -> 0
        is Row.Vid -> 1
        is Row.Item -> 2
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): RecyclerView.ViewHolder {
        if (type == 0) {
            val t = ctx.tv("", 16f, Col.TX, true)
            t.setPadding(ctx.dp(4), ctx.dp(20), ctx.dp(4), ctx.dp(8))
            t.layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            return HeadVH(t)
        }
        if (type == 1) {
            val outer = LinearLayout(ctx)
            outer.orientation = LinearLayout.VERTICAL
            outer.setPadding(ctx.dp(5), ctx.dp(5), ctx.dp(5), ctx.dp(5))
            outer.layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            val frame = RatioFrame(ctx)
            frame.background = rr(Col.CARD2, ctx.dp(10).toFloat())
            frame.clipToOutline = true
            val thumb = ImageView(ctx)
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            frame.addView(thumb, FrameLayout.LayoutParams(MATCH, MATCH))
            val dur = ctx.tv("", 10.5f)
            dur.setPadding(ctx.dp(5), ctx.dp(2), ctx.dp(5), ctx.dp(2))
            dur.background = rr(0xCC000000.toInt(), ctx.dp(4).toFloat())
            val dlp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
            dlp.setMargins(0, 0, ctx.dp(6), ctx.dp(8))
            frame.addView(dur, dlp)
            val prog = View(ctx)
            prog.setBackgroundColor(Col.AC)
            prog.pivotX = 0f
            prog.scaleX = 0f
            frame.addView(prog, FrameLayout.LayoutParams(MATCH, ctx.dp(3), Gravity.BOTTOM))
            outer.addView(frame, LinearLayout.LayoutParams(MATCH, WRAP))
            val info = LinearLayout(ctx)
            info.orientation = LinearLayout.VERTICAL
            info.setPadding(ctx.dp(2), ctx.dp(8), 0, ctx.dp(2))
            val name = ctx.tv("", 13f)
            name.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            val metaRow = LinearLayout(ctx)
            metaRow.gravity = Gravity.CENTER_VERTICAL
            val meta = ctx.tv("", 11.5f, Col.MU)
            val more = ctx.iconView(Ic.MORE, Col.MU, 18, true)
            more.setPadding(ctx.dp(6), ctx.dp(4), ctx.dp(2), ctx.dp(4))
            metaRow.addView(meta, LinearLayout.LayoutParams(0, WRAP, 1f))
            metaRow.addView(more)
            info.addView(name)
            info.addView(metaRow)
            outer.addView(info)
            outer.pressable(0.97f)
            more.pressable(0.8f)
            return VidVH(outer, thumb, dur, prog, name, meta, more)
        }
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(ctx.dp(14), ctx.dp(13), ctx.dp(12), ctx.dp(13))
        r.background = rr(Col.CARD, ctx.dp(12).toFloat())
        val lp = ViewGroup.MarginLayoutParams(MATCH, WRAP)
        lp.setMargins(ctx.dp(5), ctx.dp(3), ctx.dp(5), ctx.dp(3))
        r.layoutParams = lp
        val icon = ImageView(ctx)
        val ilp = LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22))
        ilp.rightMargin = ctx.dp(14)
        r.addView(icon, ilp)
        val tx = LinearLayout(ctx)
        tx.orientation = LinearLayout.VERTICAL
        val title = ctx.tv("", 14f)
        val sub = ctx.tv("", 12f, Col.MU)
        tx.addView(title)
        tx.addView(sub)
        r.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
        val chev = ImageView(ctx)
        chev.setImageDrawable(PathIcon(Ic.CHEVRON, Col.MU, false, ctx.dp(18)))
        r.addView(chev, LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)))
        r.pressable(0.98f)
        return ItemVH(r, icon, title, sub, chev)
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, p: Int) {
        val row = rows[p]
        if (row is Row.Head && h is HeadVH) {
            // A title ending in "." is an empty-state message; anything else is a section heading.
            val msg = row.title.endsWith(".")
            h.t.text = row.title
            h.t.textSize = if (msg) 13f else 16f
            h.t.setTextColor(if (msg) Col.MU else Col.TX)
            h.t.typeface = if (msg) Typeface.DEFAULT else Typeface.create("sans-serif-medium", Typeface.NORMAL)
            h.t.setPadding(ctx.dp(4), ctx.dp(if (msg) 16 else 20), ctx.dp(4), ctx.dp(8))
        } else if (row is Row.Vid && h is VidVH) {
            val v = row.v
            h.name.text = v.name
            h.meta.text = fmtSize(v.size) + (if (v.height > 0) "  ·  ${v.height}p" else "")
            h.dur.text = fmtTime(v.durationMs)
            val pos = store.pos(v.id)
            h.prog.scaleX = if (pos > 5000 && v.durationMs > 0) (pos.toFloat() / v.durationMs).coerceIn(0f, 1f) else 0f
            Thumbs.load(ctx, v, h.thumb)
            h.itemView.setOnClickListener { onPlay(row.group, row.group.indexOf(v)) }
            h.itemView.setOnLongClickListener { onMenu(v); true }
            h.more.setOnClickListener { onMenu(v) }
        } else if (row is Row.Item && h is ItemVH) {
            h.title.text = row.title
            h.sub.text = row.sub
            h.sub.visibility = if (row.sub.isEmpty()) View.GONE else View.VISIBLE
            val ic = row.icon
            if (ic != null) {
                h.icon.setImageDrawable(PathIcon(ic, Col.TX2, false, ctx.dp(22)))
                h.icon.visibility = View.VISIBLE
            } else h.icon.visibility = View.GONE
            // Rows with a sub-line (folders, playlists) lead somewhere, so they get a chevron.
            h.chev.visibility = if (row.sub.isEmpty()) View.GONE else View.VISIBLE
            h.itemView.setOnClickListener { row.click() }
            val lg = row.long
            if (lg != null) h.itemView.setOnLongClickListener { lg(); true } else h.itemView.setOnLongClickListener(null)
        }
    }
}

fun android.app.Activity.buildRecycler(
    rows: List<Row>, store: Store,
    onPlay: (List<Video>, Int) -> Unit, onMenu: (Video) -> Unit
): RecyclerView {
    val span = maxOf(2, resources.displayMetrics.widthPixels / dp(170))
    val rv = RecyclerView(this)
    val lm = androidx.recyclerview.widget.GridLayoutManager(this, span)
    lm.spanSizeLookup = object : androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup() {
        override fun getSpanSize(position: Int): Int = if (rows[position] is Row.Vid) 1 else span
    }
    rv.layoutManager = lm
    rv.adapter = RowAdapter(this, rows, store, onPlay, onMenu)
    rv.setPadding(dp(11), 0, dp(11), dp(8))
    rv.clipToPadding = false
    return rv
}
