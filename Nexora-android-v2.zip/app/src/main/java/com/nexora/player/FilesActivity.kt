package com.nexora.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** "My Files" style hub: Recent, Categories, Collections, Storage and Recycle bin. */
class FilesActivity : Activity() {
    private lateinit var store: Store
    private lateinit var body: FrameLayout
    private lateinit var titleTv: TextView
    private var videos: List<Video> = emptyList()
    private var audios: List<Video> = emptyList()
    private var downloads: List<Video> = emptyList()
    private var trash: List<Video> = emptyList()
    private var screen = "hub"
    private var folderOpen: String? = null
    private var query = ""
    private var safeOpen = false
    private var launching = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Col.BG)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(8), dp(10), dp(8), dp(6))
        val back = iconView(Ic.BACK, Col.TX, 24)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.pressable(0.85f)
        back.setOnClickListener { onBackPressed() }
        titleTv = tv("My Files", 20f, Col.TX, true)
        val search = iconView(Ic.SEARCH, Col.TX, 22)
        search.setPadding(dp(10), dp(10), dp(10), dp(10))
        search.pressable(0.85f)
        search.setOnClickListener { searchDialog() }
        val more = iconView(Ic.MORE, Col.TX, 22, true)
        more.setPadding(dp(10), dp(10), dp(10), dp(10))
        more.pressable(0.85f)
        more.setOnClickListener { moreMenu() }
        head.addView(back)
        head.addView(titleTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(search)
        head.addView(more)
        root.addView(head)
        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        launching = false
        reload()
    }

    override fun onStop() {
        super.onStop()
        if (!launching) {
            safeOpen = false
            if (screen == "safe") { screen = "hub"; folderOpen = null }
        }
    }

    private fun reload() {
        Thread {
            val v = Library.scan(this)
            val a = Media.audio(this)
            val d = Media.downloads(this)
            val t = Media.trash(this)
            runOnUiThread { videos = v; audios = a; downloads = d; trash = t; render() }
        }.start()
    }

    private fun vis(l: List<Video>): List<Video> = l.filter { !store.isHidden(it.id) }
    private fun everything(): List<Video> = vis(videos) + vis(audios)
    private fun starred(): List<Video> = everything().filter { store.isFav(it.id) }
    private fun hidden(): List<Video> = (videos + audios).filter { store.isHidden(it.id) }
    private fun go(s: String) { screen = s; folderOpen = null; render() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dlg(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun render() {
        titleTv.text = when (screen) {
            "recent" -> "Recent files"
            "videos" -> "Videos"
            "audio" -> "Audio"
            "downloads" -> "Downloads"
            "starred" -> "Starred"
            "safe" -> "Safe folder"
            "recycle" -> "Recycle bin"
            "folders" -> folderOpen ?: "Internal Storage"
            "search" -> "Search"
            else -> "My Files"
        }
        body.removeAllViews()
        val v: View = if (screen == "hub") hubView() else buildRecycler(
            rowsFor(), store,
            { list, i ->
                if (screen == "recycle") trashDialog(list[i])
                else { launching = true; startActivity(PlayerActivity.intent(this, list, i)) }
            },
            { v -> if (screen == "recycle") trashDialog(v) else itemMenu(v) }
        )
        body.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun rowsFor(): List<Row> {
        val rows = ArrayList<Row>()
        fun list(l: List<Video>, empty: String) {
            if (l.isEmpty()) rows.add(Row.Head(empty)) else l.forEach { rows.add(Row.Vid(it, l)) }
        }
        when (screen) {
            "recent" -> {
                val all = everything()
                val played = store.history().mapNotNull { id -> all.firstOrNull { it.id == id } }
                if (played.isNotEmpty()) { rows.add(Row.Head("Recently played")); played.forEach { rows.add(Row.Vid(it, played)) } }
                val added = (vis(videos).take(20) + vis(audios).take(10)).filter { !played.contains(it) }
                if (added.isNotEmpty()) { rows.add(Row.Head("Recently added")); added.forEach { rows.add(Row.Vid(it, added)) } }
                if (rows.isEmpty()) rows.add(Row.Head("Nothing here yet."))
            }
            "videos" -> list(vis(videos), "No videos found.")
            "audio" -> list(vis(audios), "No audio files found.")
            "downloads" -> list(vis(downloads), "No videos or audio in Downloads.")
            "starred" -> list(starred(), "Nothing starred yet. Use ⋯ on any file.")
            "safe" -> list(hidden(), "Safe folder is empty. Use ⋯ on any file to move it here.")
            "recycle" -> {
                if (Build.VERSION.SDK_INT < 30) rows.add(Row.Head("Recycle bin needs Android 11 or newer."))
                else {
                    rows.add(Row.Head("Tap a file to restore it or delete it permanently."))
                    trash.forEach { rows.add(Row.Vid(it, trash)) }
                }
            }
            "search" -> list(everything().filter { it.name.contains(query, true) }, "No files match “$query”.")
            "folders" -> {
                val groups = everything().groupBy { it.folder }
                val open = folderOpen
                if (open != null && groups.containsKey(open)) {
                    rows.add(Row.Item("Back to folders", "", { folderOpen = null; render() }, null, Ic.BACK))
                    val l = groups[open]!!
                    l.forEach { rows.add(Row.Vid(it, l)) }
                } else {
                    folderOpen = null
                    if (groups.isEmpty()) rows.add(Row.Head("No folders yet."))
                    groups.entries.sortedBy { it.key.lowercase() }.forEach { e ->
                        rows.add(Row.Item(e.key, "${e.value.size} files", { folderOpen = e.key; render() }, null, Ic.FOLDER))
                    }
                }
            }
        }
        return rows
    }

    // ---- hub ----
    private fun tile(path: String, color: Int, title: String, sub: String, chevron: Boolean, click: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.gravity = Gravity.CENTER_VERTICAL
        t.setPadding(dp(12), dp(12), dp(12), dp(12))
        t.background = rr(Col.CARD, dp(12).toFloat())
        val chip = FrameLayout(this)
        chip.background = rr(Col.CARD2, dp(10).toFloat())
        chip.addView(iconView(path, color, 22), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        t.addView(chip, LinearLayout.LayoutParams(dp(40), dp(40)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.setPadding(dp(14), 0, dp(8), 0)
        tx.addView(tv(title, 14f))
        if (sub.isNotEmpty()) tx.addView(tv(sub, 12f, Col.MU))
        t.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (chevron) t.addView(iconView(Ic.CHEVRON, Col.MU, 18))
        t.pressable(0.97f)
        t.setOnClickListener { click() }
        return t
    }

    private fun pair(a: View, b: View?): LinearLayout {
        val r = LinearLayout(this)
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l1.setMargins(0, dp(5), dp(5), dp(5))
        r.addView(a, l1)
        val l2 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l2.setMargins(dp(5), dp(5), 0, dp(5))
        r.addView(b ?: View(this), l2)
        return r
    }

    private fun storageText(): String = try {
        val s = StatFs(Environment.getExternalStorageDirectory().path)
        val total = s.blockCountLong * s.blockSizeLong
        val free = s.availableBlocksLong * s.blockSizeLong
        String.format("%.2f GB / %.2f GB", (total - free) / 1e9, total / 1e9)
    } catch (e: Exception) { "" }

    private fun hubView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(4), dp(16), dp(24))
        fun head(t: String) {
            val h = tv(t.uppercase(), 11.5f, Col.MU)
            h.letterSpacing = 0.08f
            h.setPadding(dp(4), dp(22), 0, dp(6))
            col.addView(h)
        }
        fun full(v: View) {
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(6)
            col.addView(v, lp)
        }
        full(tile(Ic.HISTORY, Col.TX2, "Recent files", "", true) { go("recent") })
        head("Categories")
        col.addView(pair(
            tile(Ic.VIDEO, Col.TX2, "Videos", "${vis(videos).size} items", false) { go("videos") },
            tile(Ic.MUSIC, Col.TX2, "Audio", "${vis(audios).size} items", false) { go("audio") }))
        col.addView(pair(
            tile(Ic.DOWNLOAD, Col.TX2, "Downloads", "${vis(downloads).size} items", false) { go("downloads") }, null))
        head("Collections")
        col.addView(pair(
            tile(Ic.STAR, Col.TX2, "Starred", "${starred().size} favorite files", false) { go("starred") },
            tile(Ic.LOCK, Col.TX2, "Safe folder", "PIN protected", false) { openSafe() }))
        head("Storage")
        full(tile(Ic.PHONE, Col.TX2, "Internal Storage", storageText(), true) { go("folders") })
        full(tile(Ic.TRASH, Col.TX2, "Recycle bin", "${trash.size} items", true) { go("recycle") })
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    // ---- safe folder ----
    private fun openSafe() {
        val h = store.pinHash
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.hint = if (h == null) "Create a 4–8 digit PIN" else "Enter PIN"
        dlg().setTitle("Safe folder").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val p = et.text.toString()
                if (!Regex("\\d{4,8}").matches(p)) toast("PIN must be 4–8 digits")
                else if (h == null) { store.pinHash = hashPin(p); safeOpen = true; go("safe") }
                else if (hashPin(p) == h) { safeOpen = true; go("safe") }
                else toast("Wrong PIN")
            }.setNegativeButton("Cancel", null).show()
    }

    // ---- item actions ----
    private fun itemMenu(v: Video) {
        val inSafe = store.isHidden(v.id)
        val fav = store.isFav(v.id)
        val items = arrayOf(
            if (fav) "Remove from Starred" else "Add to Starred",
            if (inSafe) "Remove from Safe folder" else "Move to Safe folder",
            "Delete (Recycle bin)", "Details"
        )
        dlg().setTitle(v.name).setItems(items) { _, w ->
            if (w == 0) { store.toggleFav(v.id); render() }
            else if (w == 1) {
                if (!inSafe && store.pinHash == null) toast("Open Safe folder once to create a PIN first")
                else { store.toggleHidden(v.id); render() }
            }
            else if (w == 2) trashItem(v, true)
            else dlg().setTitle("Details")
                .setMessage("${fmtSize(v.size)}   ${fmtTime(v.durationMs)}\nFolder: ${v.folder}")
                .setPositiveButton("OK", null).show()
        }.show()
    }

    private fun trashItem(v: Video, toTrash: Boolean) {
        if (Build.VERSION.SDK_INT < 30) { toast("Recycle bin needs Android 11 or newer"); return }
        try {
            val pi = MediaStore.createTrashRequest(contentResolver, listOf(v.uri), toTrash)
            @Suppress("DEPRECATION")
            startIntentSenderForResult(pi.intentSender, if (toTrash) 31 else 32, null, 0, 0, 0)
        } catch (e: Exception) { toast("Couldn’t move this file") }
    }

    private fun trashDialog(v: Video) {
        dlg().setTitle(v.name).setItems(arrayOf("Restore", "Delete permanently")) { _, w ->
            if (w == 0) trashItem(v, false)
            else if (Build.VERSION.SDK_INT >= 30) {
                try {
                    val pi = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
                    @Suppress("DEPRECATION")
                    startIntentSenderForResult(pi.intentSender, 33, null, 0, 0, 0)
                } catch (e: Exception) { toast("Couldn’t delete this file") }
            }
        }.show()
    }

    private fun searchDialog() {
        val et = EditText(this)
        et.hint = "Search videos and audio"
        et.setSingleLine()
        dlg().setTitle("Search").setView(et)
            .setPositiveButton("Search") { _, _ -> query = et.text.toString().trim(); if (query.isNotEmpty()) go("search") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun moreMenu() {
        dlg().setItems(arrayOf("Open a file from storage…", "Rescan")) { _, w ->
            if (w == 0) {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
                @Suppress("DEPRECATION")
                startActivityForResult(i, 11)
            } else { reload(); toast("Scanning…") }
        }.show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 11 && res == RESULT_OK) {
            val u: Uri = data?.data ?: return
            val v = Video(u.toString().hashCode().toLong(), queryName(u), "Files", 0, 0, 0, 0, u)
            launching = true
            startActivity(PlayerActivity.intent(this, listOf(v), 0))
        } else if (rc in 31..33) reload()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (screen == "folders" && folderOpen != null) { folderOpen = null; render() }
        else if (screen != "hub") go("hub")
        else super.onBackPressed()
    }
}
