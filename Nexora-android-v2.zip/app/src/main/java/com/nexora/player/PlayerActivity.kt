@file:OptIn(UnstableApi::class)

package com.nexora.player

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : Activity() {
    companion object {
        fun intent(ctx: Context, list: List<Video>, index: Int): Intent {
            val start = maxOf(0, index - 100)
            val sub = list.subList(start, minOf(list.size, start + 200))
            val i = Intent(ctx, PlayerActivity::class.java)
            i.putStringArrayListExtra("uris", ArrayList(sub.map { it.uri.toString() }))
            i.putExtra("ids", sub.map { it.id }.toLongArray())
            i.putStringArrayListExtra("names", ArrayList(sub.map { it.name }))
            i.putExtra("index", index - start)
            return i
        }
    }

    private lateinit var store: Store
    private lateinit var audio: AudioManager
    private lateinit var root: FrameLayout
    private lateinit var pv: PlayerView
    private lateinit var controls: FrameLayout
    private lateinit var title: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tDur: TextView
    private lateinit var btnPlay: ImageView
    private lateinit var hud: TextView
    private lateinit var unlock: TextView
    private lateinit var sBright: VSlider
    private lateinit var sVol: VSlider

    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private val ui = Handler(Looper.getMainLooper())
    private var items = mutableListOf<MediaItem>()
    private var ids = LongArray(0)
    private var names = ArrayList<String>()
    private var startIndex = 0
    private var locked = false
    private var dragging = false
    private var userRotated = false
    private var inPip = false
    private var resize = 0
    private var bright = 0.5f
    private var volF = 0.5f
    private var ticks = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Fit", "Fill screen (crop)", "Stretch")
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)

    private val hideRun = Runnable {
        if (controller?.isPlaying == true && !inPip) controls.fadeOut()
    }
    private val hudHide = Runnable { hud.visibility = View.GONE }
    private val unlockHide = Runnable { unlock.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null) {
                val dur = c.duration
                val pos = c.currentPosition
                if (dur > 0 && !dragging) seek.progress = (pos * 1000 / dur).toInt()
                if (!dragging) tCur.text = fmtTime(pos)
                tDur.text = if (dur > 0) fmtTime(dur) else "0:00"
                ticks++
                if (ticks % 6 == 0) savePos()
            }
            ui.postDelayed(this, 500)
        }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            btnPlay.setImageDrawable(PathIcon(if (isPlaying) Ic.PAUSE else Ic.PLAY, Color.BLACK, true, dp(28)))
            if (isPlaying) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                showControls()
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                ui.removeCallbacks(hideRun)
            }
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncTitle()
            currentId()?.let { store.addHistory(it) }
        }
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (!userRotated && videoSize.width > 0) {
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
        override fun onPlayerError(error: PlaybackException) {
            toast("This file can’t be played on this device. Try another format.")
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val data = intent.data
        val uris: List<String>
        if (intent.hasExtra("uris")) {
            uris = intent.getStringArrayListExtra("uris") ?: ArrayList()
            ids = intent.getLongArrayExtra("ids") ?: LongArray(0)
            names = intent.getStringArrayListExtra("names") ?: ArrayList()
            startIndex = intent.getIntExtra("index", 0)
        } else if (data != null) {
            uris = listOf(data.toString())
            ids = longArrayOf(data.toString().hashCode().toLong())
            names = arrayListOf(queryName(data))
        } else {
            finish()
            return
        }
        if (uris.isEmpty() || ids.size != uris.size || names.size != uris.size || startIndex !in uris.indices) {
            finish()
            return
        }
        items = uris.indices.map { i ->
            MediaItem.Builder()
                .setUri(Uri.parse(uris[i]))
                .setMediaId(ids[i].toString())
                .setMediaMetadata(MediaMetadata.Builder().setTitle(names[i]).build())
                .build()
        }.toMutableList()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val wic = WindowInsetsControllerCompat(window, window.decorView)
        wic.hide(WindowInsetsCompat.Type.systemBars())
        wic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp

        volF = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        buildUi()
    }

    private fun circle(path: String, size: Int, pad: Int, bg: Int, fg: Int): ImageView {
        val iv = iconView(path, fg, size - pad * 2, true)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(bg)
        iv.background = g
        iv.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        return iv
    }

    private fun sliderBox(s: VSlider, label: String): View {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.gravity = Gravity.CENTER_HORIZONTAL
        b.background = rr(0x66000000, dp(20).toFloat())
        b.setPadding(dp(8), dp(10), dp(8), dp(10))
        b.addView(s, LinearLayout.LayoutParams(dp(30), dp(130)))
        b.addView(tv(label, 10f, Color.WHITE))
        return b
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.useController = false
        root.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
        controls = FrameLayout(this)
        root.addView(controls, FrameLayout.LayoutParams(MATCH, MATCH))

        // top bar
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(24), dp(8), dp(24), dp(8))
        top.setBackgroundColor(0x88000000.toInt())
        val back = iconView(Ic.BACK, Color.WHITE, 24)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.pressable(0.85f)
        back.setOnClickListener { finish() }
        title = tv("", 14f)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val more = iconView(Ic.MORE, Color.WHITE, 24, true)
        more.setPadding(dp(10), dp(10), dp(10), dp(10))
        more.pressable(0.85f)
        more.setOnClickListener { showMenu() }
        top.addView(back)
        top.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(more)
        controls.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        // side sliders
        sBright = VSlider(this)
        sVol = VSlider(this)
        sBright.value = bright
        sVol.value = volF
        sBright.onChange = { setBrightness(it) }
        sVol.onChange = { setVolume(it) }
        val lpB = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL)
        lpB.marginStart = dp(28)
        controls.addView(sliderBox(sBright, "Brightness"), lpB)
        val lpV = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL)
        lpV.marginEnd = dp(28)
        controls.addView(sliderBox(sVol, "Volume"), lpV)

        // bottom: time + seek + buttons
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(28), dp(28), dp(28), dp(12))
        bottom.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xCC000000.toInt()))
        val timeRow = LinearLayout(this)
        timeRow.gravity = Gravity.CENTER_VERTICAL
        tCur = tv("0:00", 12f)
        tDur = tv("0:00", 12f)
        seek = SeekBar(this)
        seek.max = 1000
        seek.progressTintList = ColorStateList.valueOf(Col.AC)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = controller?.duration ?: 0L
                    if (d > 0) tCur.text = fmtTime(d * p / 1000)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                val c = controller
                if (c != null && c.duration > 0) c.seekTo(c.duration * (s?.progress ?: 0) / 1000)
            }
        })
        timeRow.addView(tCur)
        timeRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        timeRow.addView(tDur)
        bottom.addView(timeRow)

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val lock = iconView(Ic.LOCK, Color.WHITE, 24)
        lock.setPadding(dp(10), dp(10), dp(10), dp(10))
        lock.pressable(0.85f)
        lock.setOnClickListener { locked = true; controls.fadeOut(); toast("Controls locked") }
        val prev = circle(Ic.PREV, 40, 11, Color.WHITE, Color.BLACK)
        prev.pressable(0.86f)
        prev.setOnClickListener { step(-1) }
        btnPlay = circle(Ic.PLAY, 60, 16, Color.WHITE, Color.BLACK)
        btnPlay.pressable(0.9f)
        btnPlay.setOnClickListener { togglePlay() }
        val next = circle(Ic.NEXT, 40, 11, Color.WHITE, Color.BLACK)
        next.pressable(0.86f)
        next.setOnClickListener { step(1) }
        val rot = iconView(Ic.ROTATE, Color.WHITE, 24)
        rot.setPadding(dp(10), dp(10), dp(10), dp(10))
        rot.pressable(0.85f)
        rot.setOnClickListener {
            userRotated = true
            val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        fun spacer() = View(this)
        row.addView(lock)
        row.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(prev)
        row.addView(spacer(), LinearLayout.LayoutParams(dp(20), 1))
        row.addView(btnPlay)
        row.addView(spacer(), LinearLayout.LayoutParams(dp(20), 1))
        row.addView(next)
        row.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(rot)
        bottom.addView(row)
        controls.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        // HUD and unlock
        hud = tv("", 16f, Color.WHITE, true)
        hud.setPadding(dp(18), dp(10), dp(18), dp(10))
        hud.background = rr(0xAA000000.toInt(), dp(10).toFloat())
        hud.visibility = View.GONE
        root.addView(hud, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        unlock = tv("Tap to unlock", 14f, 0xFF0B0B0B.toInt(), true)
        unlock.setPadding(dp(20), dp(10), dp(20), dp(10))
        unlock.background = rr(Col.AC, dp(20).toFloat())
        unlock.visibility = View.GONE
        unlock.pressable(0.92f)
        unlock.setOnClickListener { locked = false; unlock.visibility = View.GONE; showControls() }
        val ulp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        ulp.bottomMargin = dp(40)
        root.addView(unlock, ulp)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    unlock.visibility = View.VISIBLE
                    ui.removeCallbacks(unlockHide)
                    ui.postDelayed(unlockHide, 2500)
                } else if (controls.visibility == View.VISIBLE && controls.alpha > 0.5f) controls.fadeOut()
                else showControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = root.width
                if (e.x < w / 3f) seekBy(-store.seekSec * 1000L)
                else if (e.x > w * 2 / 3f) seekBy(store.seekSec * 1000L)
                else togglePlay()
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || abs(dy) < abs(dx)) return false
                val d = dy / root.height * 1.2f
                if (e1.x < root.width / 2f) setBrightness(bright + d) else setVolume(volF + d)
                return true
            }
        })
        root.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
        setContentView(root)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hudShow(s: String) {
        hud.text = s
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hudHide)
        ui.postDelayed(hudHide, 900)
    }

    private fun showControls() {
        if (locked || inPip) return
        controls.fadeIn()
        ui.removeCallbacks(hideRun)
        ui.postDelayed(hideRun, 3500)
    }

    private fun setBrightness(v: Float) {
        bright = v.coerceIn(0.05f, 1f)
        val lp = window.attributes
        lp.screenBrightness = bright
        window.attributes = lp
        sBright.value = bright
        hudShow("Brightness ${(bright * 100).toInt()}%")
    }

    private fun setVolume(v: Float) {
        volF = v.coerceIn(0f, 1f)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volF * max).roundToInt(), 0)
        sVol.value = volF
        hudShow("Volume ${(volF * 100).toInt()}%")
    }

    private fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    private fun seekBy(ms: Long) {
        val c = controller ?: return
        val d = c.duration
        val t = c.currentPosition + ms
        c.seekTo(if (d > 0) t.coerceIn(0L, d) else maxOf(0L, t))
        hudShow((if (ms > 0) "+" else "−") + abs(ms / 1000) + " s")
    }

    private fun step(dir: Int) {
        val c = controller ?: return
        if (dir > 0) { if (c.hasNextMediaItem()) c.seekToNextMediaItem() else toast("End of queue") }
        else { if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem() else toast("Start of queue") }
    }

    private fun currentId(): Long? = ids.getOrNull(controller?.currentMediaItemIndex ?: -1)

    private fun syncTitle() {
        title.text = names.getOrNull(controller?.currentMediaItemIndex ?: startIndex) ?: ""
    }

    private fun savePos() {
        val c = controller ?: return
        val id = currentId() ?: return
        val dur = c.duration
        val pos = c.currentPosition
        if (dur > 0 && pos > dur - 3000) store.clearPos(id) else if (pos > 3000) store.savePos(id, pos)
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try { onConnected(f.get()) } catch (e: Exception) { toast("Couldn’t start the player") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onConnected(c: MediaController) {
        controller = c
        pv.player = c
        c.addListener(listener)
        val same = c.currentMediaItem?.mediaId == ids[startIndex].toString() && c.mediaItemCount == items.size
        if (!same) {
            val pos = store.pos(ids[startIndex])
            c.setPlaybackSpeed(store.speed)
            c.setMediaItems(items, startIndex, if (pos > 5000) pos else 0L)
            c.prepare()
            c.play()
            store.addHistory(ids[startIndex])
        }
        syncTitle()
        listener.onIsPlayingChanged(c.isPlaying)
        ui.removeCallbacks(tick)
        ui.post(tick)
        showControls()
    }

    override fun onStop() {
        super.onStop()
        savePos()
        ui.removeCallbacks(tick)
        if (!store.bgAudio) controller?.pause()
        controller?.removeListener(listener)
        pv.player = null
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        if (controller?.isPlaying == true && !locked) enterPip()
    }

    private fun enterPip() {
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
            toast("Picture-in-picture isn’t available")
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        controls.visibility = if (inPip) View.GONE else View.VISIBLE
        if (!inPip) showControls()
    }

    // ---- menu ----
    private fun dlg(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun showMenu() {
        showControls()
        val labels = arrayOf("Playback speed", "Aspect ratio", "Audio track", "Subtitles", "Sleep timer", "Picture in picture")
        dlg().setItems(labels) { _, i ->
            when (i) {
                0 -> speedDialog()
                1 -> aspectDialog()
                2 -> audioDialog()
                3 -> subDialog()
                4 -> sleepDialog()
                else -> enterPip()
            }
        }.show()
    }

    private fun speedDialog() {
        val c = controller ?: return
        val labels = speeds.map { if (it % 1f == 0f) "${it.toInt()}x" else "${it}x" }.toTypedArray()
        dlg().setTitle("Playback speed")
            .setSingleChoiceItems(labels, speeds.indexOfFirst { it == c.playbackParameters.speed }) { d, w ->
                c.setPlaybackSpeed(speeds[w])
                d.dismiss()
            }.show()
    }

    private fun aspectDialog() {
        dlg().setTitle("Aspect ratio").setSingleChoiceItems(resizeNames, resize) { d, w ->
            resize = w
            pv.resizeMode = resizeModes[w]
            d.dismiss()
        }.show()
    }

    private fun audioDialog() {
        val c = controller ?: return
        val groups = c.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        if (groups.isEmpty()) { toast("No audio tracks found"); return }
        val labels = groups.mapIndexed { i, g ->
            val f = g.getTrackFormat(0)
            (f.label ?: f.language ?: "Track ${i + 1}") + (if (g.isSelected) "   ✓" else "")
        }.toTypedArray()
        dlg().setTitle("Audio track").setItems(labels) { _, w ->
            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                .setOverrideForType(TrackSelectionOverride(groups[w].mediaTrackGroup, 0)).build()
        }.show()
    }

    private fun setTextDisabled(off: Boolean) {
        val c = controller ?: return
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, off).build()
    }

    private fun subDialog() {
        dlg().setTitle("Subtitles").setItems(arrayOf("Load subtitle file (.srt, .vtt)", "Turn off", "Turn on")) { _, w ->
            if (w == 0) {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                @Suppress("DEPRECATION")
                startActivityForResult(i, 21)
            } else setTextDisabled(w == 1)
        }.show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val u = data?.data ?: return
        if (rc == 21 && res == RESULT_OK) applySub(u)
    }

    private fun applySub(u: Uri) {
        val c = controller ?: return
        val idx = c.currentMediaItemIndex
        val n = queryName(u).lowercase()
        val mime = if (n.endsWith(".srt")) MimeTypes.APPLICATION_SUBRIP
        else if (n.endsWith(".ass") || n.endsWith(".ssa")) MimeTypes.TEXT_SSA
        else MimeTypes.TEXT_VTT
        val sub = MediaItem.SubtitleConfiguration.Builder(u)
            .setMimeType(mime).setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        items[idx] = items[idx].buildUpon().setSubtitleConfigurations(listOf(sub)).build()
        val pos = c.currentPosition
        val was = c.isPlaying
        c.setMediaItems(items, idx, pos)
        c.prepare()
        if (was) c.play()
        toast("Subtitles loaded")
    }

    private fun sleepDialog() {
        val mins = intArrayOf(15, 30, 60, 0)
        val labels = arrayOf("15 minutes", "30 minutes", "60 minutes", "Off")
        dlg().setTitle("Sleep timer").setItems(labels) { _, w ->
            ui.removeCallbacks(sleepRun)
            if (mins[w] > 0) {
                ui.postDelayed(sleepRun, mins[w] * 60_000L)
                toast("Will pause in ${mins[w]} minutes")
            } else toast("Sleep timer off")
        }.show()
    }

    private val sleepRun = Runnable { controller?.pause(); toast("Sleep timer: paused") }
}
