package com.nexora.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.PathParser

const val MATCH = -1
const val WRAP = -2

object Col {
    val BG = 0xFF000000.toInt()
    val CARD = 0xFF121212.toInt()
    val CARD2 = 0xFF1C1C1C.toInt()
    val LINE = 0xFF222222.toInt()
    val AC = 0xFFA78BFA.toInt()
    val TX = 0xFFF2F2F2.toInt()
    val MU = 0xFF8A8A8A.toInt()
}

object Ic {
    const val HOME = "M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"
    const val FOLDER = "M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
    const val LIST = "M4 6h12M4 11h12M4 16h8M18 14v6l4-3z"
    const val HISTORY = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 7v5l3 2"
    const val SETTINGS = "M4 7h10M18 7h2M4 17h2M10 17h10M16 5a2 2 0 1 0 0 4a2 2 0 1 0 0-4zM8 15a2 2 0 1 0 0 4a2 2 0 1 0 0-4z"
    const val PLAY = "M7 4.5v15l12-7.5z"
    const val PAUSE = "M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"
    const val BACK = "M15 5l-7 7 7 7"
    const val PREV = "M6 5v14M19 5L9 12l10 7z"
    const val NEXT = "M18 5v14M5 5l10 7-10 7z"
    const val LOCK = "M7 11h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zM8 11V8a4 4 0 0 1 8 0v3"
    const val ROTATE = "M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3M18 3v4h-4M6 21v-4h4"
    const val CHEVRON = "M9 5l7 7-7 7"
    const val VIDEO = "M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM10 8.5v7l5.5-3.5z"
    const val MUSIC = "M9 18V6l10-2v12M9 18a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0zM19 16a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0z"
    const val DOWNLOAD = "M12 4v11M7 11l5 5 5-5M5 20h14"
    const val STAR = "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"
    const val PHONE = "M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM11 18h2"
    const val TRASH = "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"
    const val SEARCH = "M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14zM16 16l5 5"
    const val MORE = "M12 3.5a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3zM12 10.5a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3zM12 17.5a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3z"
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class PathIcon(data: String, color: Int, private val filled: Boolean, private val size: Int) : Drawable() {
    private val path: Path = PathParser.createPathFromPathData(data)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = if (filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
        strokeWidth = 1.7f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }
    override fun draw(canvas: Canvas) {
        val b = bounds
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.scale(b.width() / 24f, b.height() / 24f)
        canvas.drawPath(path, paint)
        canvas.restore()
    }
    override fun getIntrinsicWidth(): Int = size
    override fun getIntrinsicHeight(): Int = size
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun Context.iconView(path: String, color: Int = Col.TX, sizeDp: Int = 24, filled: Boolean = false): ImageView {
    val iv = ImageView(this)
    iv.setImageDrawable(PathIcon(path, color, filled, dp(sizeDp)))
    return iv
}

fun Context.tv(s: String, sp: Float = 14f, color: Int = Col.TX, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = sp
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun rr(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    if (strokeW > 0) g.setStroke(strokeW, strokeColor)
    return g
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val c = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, c) else String.format("%d:%02d", m, c)
}

fun fmtSize(b: Long): String =
    if (b >= 1_000_000_000L) String.format("%.2f GB", b / 1e9) else String.format("%.1f MB", b / 1e6)

fun Context.queryName(u: Uri): String {
    try {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Video"
        }
    } catch (e: Exception) {
    }
    return u.lastPathSegment ?: "Video"
}

/** Vertical slider used for brightness and volume. */
class VSlider(ctx: Context) : View(ctx) {
    var value = 0.5f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF; strokeWidth = ctx.dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Col.AC; strokeWidth = ctx.dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(c: Canvas) {
        val x = width / 2f
        val pad = height * 0.06f
        val top = pad
        val bot = height - pad
        c.drawLine(x, top, x, bot, track)
        val y = bot - (bot - top) * value
        c.drawLine(x, bot, x, y, fill)
        c.drawCircle(x, y, context.dp(7).toFloat(), thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent.requestDisallowInterceptTouchEvent(true)
        val pad = height * 0.06f
        value = 1f - ((e.y - pad) / (height - 2 * pad))
        onChange?.invoke(value)
        return true
    }
}
