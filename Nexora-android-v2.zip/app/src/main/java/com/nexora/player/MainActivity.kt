package com.nexora.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private var all: List<Video> = emptyList()
    private var tab = 0
    private var query = ""
    private var openFolder: String? = null
    private var openPlaylist: String? = null
    private var granted = false
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
    private val seekSteps = intArrayOf(5, 10, 15, 30)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Col.BG)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(12), dp(16), dp(8))
        val logo = tv("NEXORA", 16f, Col.TX, true)
        logo.letterSpacing = 0.14f
        head.addView(logo, LinearLayout.LayoutParams(0, WRAP, 1f))
        val files = tv("Files", 13f, 0xFF0B0B0B.toInt(), true)
        files.setPadding(dp(14), dp(8), dp(14), dp(8))
        files.background = rr(Col.AC, dp(8).toFloat())
        files.setOnClickListener { startActivity(Intent(this, FilesActivity::class.java)) }
        head.addView(files)
        root.addView(head)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        nav = LinearLayout(this)
        nav.setBackgroundColor(0xFF0A0A0A.toInt())
        root.addView(nav)
        setContentView(root)
        if (checkSelfPermission(perm()) != PackageManager.PERMISSION_GRANTED) askPermission()
    }

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun askPermission() {
        val need = ArrayList<String>()
        need.add(perm())
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.READ_MEDIA_AUDIO)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    /** Re-reads the whole device library, so new videos appear automatically. */
    private fun refresh() {
        granted = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED
        if (!granted) { render(); return }
        Thread {
            val l = Library.scan(this)
            runOnUiThread { all = l.filter { !store.isHidden(it.id) }; render() }
        }.start()
    }

    private fun render() {
        nav.removeAllViews()
        val names = listOf("Home", "Folders", "Playlists", "History", "Settings")
        val icons = listOf(Ic.HOME, Ic.FOLDER, Ic.LIST, Ic.HISTORY, Ic.SETTINGS)
        for (i in 0..4) {
            val c = if (i == tab) Col.AC else Col.MU
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.setPadding(0, dp(8), 0, dp(8))
            item.addView(iconView(icons[i], c, 22))
            item.addView(tv(names[i], 11f, c))
            item.setOnClickListener { tab = i; openFolder = null; openPlaylist = null; render() }
            nav.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        content.removeAllViews()
        val v: View = when {
            !granted -> permView()
            tab == 0 -> homeView()
            tab == 1 -> recycler(folderRows())
            tab == 2 -> recycler(playlistRows())
            tab == 3 -> recycler(historyRows())
            else -> settingsView()
        }
        content.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun permView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(32), 0, dp(32), 0)
        val t = tv("Allow access to videos so NEXORA can find every video on your phone automatically.", 14f, Col.MU)
        t.gravity = Gravity.CENTER
        col.addView(t)
        val b = tv("Allow access", 14f, 0xFF0B0B0B.toInt(), true)
        b.setPadding(dp(20), dp(10), dp(20), dp(10))
        b.background = rr(Col.AC, dp(8).toFloat())
        b.setOnClickListener { askPermission() }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = dp(16)
        col.addView(b, lp)
        return col
    }

    private fun recycler(rows: List<Row>): RecyclerView {
        val span = maxOf(2, resources.displayMetrics.widthPixels / dp(170))
        val rv = RecyclerView(this)
        val lm = GridLayoutManager(this, span)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (rows[position] is Row.Vid) 1 else span
        }
        rv.layoutManager = lm
        rv.adapter = RowAdapter(this, rows, store, { list, i -> play(list, i) }, { v -> menu(v) })
        rv.setPadding(dp(11), 0, dp(11), dp(8))
        rv.clipToPadding = false
        return rv
    }

    private fun homeView(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val et = EditText(this)
        et.hint = "Search videos"
        et.setHintTextColor(Col.MU)
        et.setTextColor(Col.TX)
        et.textSize = 14f
        et.setSingleLine()
        et.background = rr(Col.CARD, dp(8).toFloat(), Col.LINE, dp(1))
        et.setPadding(dp(14), dp(10), dp(14), dp(10))
        et.setText(query)
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s.toString()
                box.removeViewAt(1)
                box.addView(recycler(homeRows()), 1, LinearLayout.LayoutParams(MATCH, 0, 1f))
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(dp(16), dp(4), dp(16), dp(4))
        box.addView(et, lp)
        box.addView(recycler(homeRows()), LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun homeRows(): List<Row> {
        val l = all.filter { query.isBlank() || it.name.contains(query, true) }
        if (l.isEmpty()) return listOf(Row.Head(if (all.isEmpty()) "No videos found on this device." else "No videos match your search."))
        val rows = ArrayList<Row>()
        if (query.isBlank()) {
            val cont = l.filter { val p = store.pos(it.id); p > 5000 && it.durationMs > 0 && p < it.durationMs - 8000 }
            if (cont.isNotEmpty()) { rows.add(Row.Head("Continue watching")); cont.forEach { rows.add(Row.Vid(it, cont)) } }
            val favs = l.filter { store.isFav(it.id) }
            if (favs.isNotEmpty()) { rows.add(Row.Head("Favorites")); favs.forEach { rows.add(Row.Vid(it, favs)) } }
        }
        rows.add(Row.Head(if (query.isBlank()) "All videos" else "Results"))
        l.forEach { rows.add(Row.Vid(it, l)) }
        return rows
    }

    private fun backRow(label: String): Row =
        Row.Item("‹  $label", "", { openFolder = null; openPlaylist = null; render() })

    private fun folderRows(): List<Row> {
        val groups = all.groupBy { it.folder }
        val open = openFolder
        if (open != null && groups.containsKey(open)) {
            val l = groups[open]!!
            val rows = ArrayList<Row>()
            rows.add(backRow(open))
            l.forEach { rows.add(Row.Vid(it, l)) }
            return rows
        }
        openFolder = null
        if (groups.isEmpty()) return listOf(Row.Head("No folders yet."))
        return groups.entries.sortedBy { it.key.lowercase() }.map { e ->
            Row.Item(e.key, "${e.value.size} videos", { openFolder = e.key; render() })
        }
    }

    private fun playlistRows(): List<Row> {
        val open = openPlaylist
        if (open != null) {
            val l = store.playlist(open).mapNotNull { id -> all.firstOrNull { it.id == id } }
            val rows = ArrayList<Row>()
            rows.add(backRow(open))
            if (l.isEmpty()) rows.add(Row.Head("Empty. Use ⋯ on any video to add it here."))
            l.forEach { rows.add(Row.Vid(it, l)) }
            return rows
        }
        val rows = ArrayList<Row>()
        rows.add(Row.Item("+  New playlist", "", { newPlaylist(null) }))
        store.playlistNames().forEach { n ->
            rows.add(Row.Item(n, "${store.playlist(n).size} videos", { openPlaylist = n; render() }, { deletePlaylist(n) }))
        }
        return rows
    }

    private fun historyRows(): List<Row> {
        val l = store.history().mapNotNull { id -> all.firstOrNull { it.id == id } }
        if (l.isEmpty()) return listOf(Row.Head("Nothing played yet."))
        val rows = ArrayList<Row>()
        rows.add(Row.Head("Recently played"))
        l.forEach { rows.add(Row.Vid(it, l)) }
        return rows
    }

    private fun speedLabel(f: Float): String = if (f % 1f == 0f) "${f.toInt()}x" else "${f}x"

    private fun settingsView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(4), dp(16), dp(16))
        fun head(t: String) {
            val h = tv(t, 13f, Col.MU)
            h.setPadding(dp(4), dp(16), 0, 0)
            col.addView(h)
        }
        fun row(t: String, sub: String, click: (() -> Unit)?, extra: View?) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(14), dp(12), dp(14), dp(12))
            r.background = rr(Col.CARD, dp(8).toFloat(), Col.CARD2, dp(1))
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(tv(t, 14f))
            if (sub.isNotEmpty()) tx.addView(tv(sub, 12f, Col.MU))
            r.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
            if (extra != null) r.addView(extra)
            if (click != null) r.setOnClickListener { click() }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(8)
            col.addView(r, lp)
        }
        head("Playback")
        row("Default speed", speedLabel(store.speed), {
            val labels = speeds.map { speedLabel(it) }.toTypedArray()
            dialog().setTitle("Default speed")
                .setSingleChoiceItems(labels, speeds.indexOf(store.speed)) { d, w -> store.speed = speeds[w]; d.dismiss(); render() }.show()
        }, null)
        row("Seek step", "${store.seekSec} seconds", {
            val labels = seekSteps.map { "$it seconds" }.toTypedArray()
            dialog().setTitle("Seek step")
                .setSingleChoiceItems(labels, seekSteps.indexOf(store.seekSec)) { d, w -> store.seekSec = seekSteps[w]; d.dismiss(); render() }.show()
        }, null)
        val sw = Switch(this)
        sw.isChecked = store.bgAudio
        sw.setOnCheckedChangeListener { _, c -> store.bgAudio = c }
        row("Background audio", "Keep playing when you leave the app", null, sw)
        head("Library")
        row("Rescan videos", "Videos are also found automatically", { refresh(); toast("Scanning…") }, null)
        head("Privacy")
        row("Clear playback history", "", { store.clearHistory(); toast("History cleared") }, null)
        row("Clear resume positions", "", { store.clearAllPos(); toast("Positions cleared") }, null)
        head("About")
        val about = tv("NEXORA 1.0\nPlay Everything. Experience More.\n\nVideos stay on your device and nothing is uploaded. Not in this version yet: equalizer, private vault, A-B repeat, Chromecast.", 12f, Col.MU)
        about.setPadding(dp(4), dp(8), dp(4), 0)
        col.addView(about)
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun dialog(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun menu(v: Video) {
        val fav = store.isFav(v.id)
        val items = arrayOf(if (fav) "Remove from favorites" else "Add to favorites", "Add to playlist", "Details")
        dialog().setTitle(v.name).setItems(items) { _, w ->
            if (w == 0) { store.toggleFav(v.id); render() }
            else if (w == 1) addToPlaylist(v)
            else dialog().setTitle("Details")
                .setMessage("${fmtSize(v.size)}   ${v.width}×${v.height}   ${fmtTime(v.durationMs)}\nFolder: ${v.folder}")
                .setPositiveButton("OK", null).show()
        }.show()
    }

    private fun addToPlaylist(v: Video) {
        val names = store.playlistNames()
        if (names.isEmpty()) { newPlaylist(v); return }
        dialog().setTitle("Add to playlist").setItems(names.toTypedArray()) { _, w ->
            store.addToPlaylist(names[w], v.id)
            toast("Added to ${names[w]}")
        }.show()
    }

    private fun newPlaylist(add: Video?) {
        val et = EditText(this)
        et.hint = "Playlist name"
        dialog().setTitle("New playlist").setView(et)
            .setPositiveButton("Create") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    store.createPlaylist(n)
                    if (add != null) store.addToPlaylist(n, add.id)
                    render()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deletePlaylist(n: String) {
        dialog().setTitle("Delete “$n”?")
            .setPositiveButton("Delete") { _, _ -> store.deletePlaylist(n); render() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun play(list: List<Video>, index: Int) {
        startActivity(PlayerActivity.intent(this, list, index))
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "video/*"
        @Suppress("DEPRECATION")
        startActivityForResult(i, 11)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val u: Uri = data?.data ?: return
        if (rc == 11 && res == RESULT_OK) {
            val v = Video(u.toString().hashCode().toLong(), queryName(u), "Files", 0, 0, 0, 0, u)
            play(listOf(v), 0)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (openFolder != null || openPlaylist != null) {
            openFolder = null
            openPlaylist = null
            render()
        } else super.onBackPressed()
    }
}
