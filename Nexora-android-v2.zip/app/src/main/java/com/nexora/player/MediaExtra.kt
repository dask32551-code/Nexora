package com.nexora.player

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore

/** Audio, Downloads and Recycle-bin queries for the Files section. */
object Media {
    const val AUDIO_OFFSET = 1L shl 40
    const val DL_OFFSET = 1L shl 41

    private fun query(ctx: Context, base: Uri, offset: Long, sel: String?, dims: Boolean, trashed: Boolean): List<Video> {
        val out = ArrayList<Video>()
        val cols = ArrayList<String>()
        cols.add(MediaStore.MediaColumns._ID)
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME)
        cols.add(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
        cols.add(MediaStore.MediaColumns.SIZE)
        cols.add(MediaStore.MediaColumns.DURATION)
        if (dims) { cols.add(MediaStore.MediaColumns.WIDTH); cols.add(MediaStore.MediaColumns.HEIGHT) }
        try {
            val c: Cursor? = if (trashed) {
                if (Build.VERSION.SDK_INT < 30) null else {
                    val b = Bundle()
                    b.putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
                    if (sel != null) b.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
                    ctx.contentResolver.query(base, cols.toTypedArray(), b, null)
                }
            } else {
                ctx.contentResolver.query(base, cols.toTypedArray(), sel, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")
            }
            c?.use { cur ->
                while (cur.moveToNext()) {
                    val id = cur.getLong(0)
                    out.add(
                        Video(
                            offset + id, cur.getString(1) ?: "File", cur.getString(2) ?: "Storage",
                            cur.getLong(3), cur.getLong(4),
                            if (dims) cur.getInt(5) else 0, if (dims) cur.getInt(6) else 0,
                            ContentUris.withAppendedId(base, id)
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun audio(ctx: Context): List<Video> =
        query(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, AUDIO_OFFSET, null, false, false)

    fun downloads(ctx: Context): List<Video> =
        query(ctx, MediaStore.Downloads.EXTERNAL_CONTENT_URI, DL_OFFSET,
            "mime_type LIKE 'video/%' OR mime_type LIKE 'audio/%'", true, false)

    fun trash(ctx: Context): List<Video> {
        if (Build.VERSION.SDK_INT < 30) return emptyList()
        return query(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, 0L, null, true, true) +
            query(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, AUDIO_OFFSET, null, false, true)
    }
}
