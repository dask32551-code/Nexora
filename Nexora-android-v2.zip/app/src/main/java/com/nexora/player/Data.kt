package com.nexora.player

import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

data class Video(
    val id: Long, val name: String, val folder: String, val size: Long,
    val durationMs: Long, val width: Int, val height: Int, val uri: Uri
)

object Library {
    /** Reads every video on the device (internal and SD card) from MediaStore. */
    fun scan(ctx: Context): List<Video> {
        val out = ArrayList<Video>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT
        )
        try {
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out.add(
                        Video(
                            id, c.getString(1) ?: "Video", c.getString(2) ?: "Internal storage",
                            c.getLong(3), c.getLong(4), c.getInt(5), c.getInt(6),
                            ContentUris.withAppendedId(base, id)
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}

class Store(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("nexora", Context.MODE_PRIVATE)

    var speed: Float
        get() = p.getFloat("speed", 1f)
        set(v) { p.edit().putFloat("speed", v).apply() }
    var seekSec: Int
        get() = p.getInt("seek", 10)
        set(v) { p.edit().putInt("seek", v).apply() }
    var bgAudio: Boolean
        get() = p.getBoolean("bg", false)
        set(v) { p.edit().putBoolean("bg", v).apply() }

    fun pos(id: Long): Long = p.getLong("pos_$id", 0L)
    fun savePos(id: Long, ms: Long) { p.edit().putLong("pos_$id", ms).apply() }
    fun clearPos(id: Long) { p.edit().remove("pos_$id").apply() }
    fun clearAllPos() {
        val e = p.edit()
        p.all.keys.filter { it.startsWith("pos_") }.forEach { e.remove(it) }
        e.apply()
    }

    private fun ids(key: String): List<Long> =
        (p.getString(key, "") ?: "").split(",").filter { it.isNotEmpty() }.map { it.toLong() }

    fun history(): List<Long> = ids("hist")
    fun addHistory(id: Long) {
        val l = listOf(id) + history().filter { it != id }
        p.edit().putString("hist", l.take(100).joinToString(",")).apply()
    }
    fun clearHistory() { p.edit().remove("hist").apply() }

    fun isFav(id: Long): Boolean = ids("fav").contains(id)
    fun toggleFav(id: Long) {
        val l = ids("fav")
        val n = if (l.contains(id)) l - id else l + id
        p.edit().putString("fav", n.joinToString(",")).apply()
    }

    private fun pls(): JSONObject = try { JSONObject(p.getString("pls", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    fun playlistNames(): List<String> = pls().keys().asSequence().toList()
    fun playlist(name: String): List<Long> {
        val a = pls().optJSONArray(name) ?: return emptyList()
        return (0 until a.length()).map { a.getLong(it) }
    }
    fun createPlaylist(name: String) {
        val o = pls()
        if (!o.has(name)) { o.put(name, JSONArray()); p.edit().putString("pls", o.toString()).apply() }
    }
    fun addToPlaylist(name: String, id: Long) {
        if (playlist(name).contains(id)) return
        val o = pls()
        val a = o.optJSONArray(name) ?: JSONArray()
        a.put(id)
        o.put(name, a)
        p.edit().putString("pls", o.toString()).apply()
    }
    fun deletePlaylist(name: String) {
        val o = pls()
        o.remove(name)
        p.edit().putString("pls", o.toString()).apply()
    }

    var pinHash: String?
        get() = p.getString("pin", null)
        set(v) { p.edit().putString("pin", v).apply() }
    fun isHidden(id: Long): Boolean = ids("hid").contains(id)
    fun toggleHidden(id: Long) {
        val l = ids("hid")
        val n = if (l.contains(id)) l - id else l + id
        p.edit().putString("hid", n.joinToString(",")).apply()
    }
}

fun hashPin(pin: String): String =
    java.security.MessageDigest.getInstance("SHA-256").digest(("nx" + pin).toByteArray())
        .joinToString("") { String.format("%02x", it) }
