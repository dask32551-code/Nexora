package com.nexora.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private lateinit var fab: ImageView
    private var all: List<Video> = emptyList()
    private var tab = 0
    private var query = ""
    private var openFolder: String? = null
    private var openPlaylist: String? = null
    private var granted = false
    /** Direction of the next screen change: 1 = forward (from right), -1 = back (from left), 0 = no animation. */
    private var slideDir = 0
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
    private val seekSteps = intArrayOf(5, 10, 15, 30)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        Col.setup(this, store.theme)
        applyBars()
        tab = b?.getInt("tab", 0) ?: 0
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Col.BG)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(12), dp(16), dp(10))
        head.addView(iconView(Ic.PLAY, Col.AC, 16, true))
        val logo = tv("NEXORA", 15f, Col.TX, true)
        logo.letterSpacing = 0.2f
        logo.setPadding(dp(8), 0, 0, 0)
        head.addView(logo, LinearLayout.LayoutParams(0, WRAP, 1f))
        val files = tv("Files", 13f, Col.TX, true)
        files.setPadding(dp(16), dp(7), dp(16), dp(7))
        files.background = rr(0, dp(18).toFloat(), Col.LINE, dp(1))
        files.pressable(0.92f)
        files.setOnClickListener { startActivity(Intent(this, FilesActivity::class.java)) }
        head.addView(files)
        root.addView(head)
        content = FrameLayout(this)
        val body = FrameLayout(this)
        body.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        // Floating play button: continues the last played video from where it stopped.
        fab = ImageView(this)
        fab.setImageDrawable(PathIcon(Ic.PLAY, Col.ON_AC, true, dp(26)))
        fab.scaleType = ImageView.ScaleType.CENTER
        fab.background = rr(Col.AC, dp(30).toFloat())
        fab.elevation = dp(6).toFloat()
        fab.contentDescription = "Continue last video"
        fab.visibility = View.GONE
        fab.pressable(0.92f)
        fab.setOnClickListener {
            val v = store.history().firstNotNullOfOrNull { id -> all.firstOrNull { it.id == id } }
            if (v != null) play(all, all.indexOf(v)) else toast("Nothing played yet")
        }
        val flp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END)
        flp.setMargins(0, 0, dp(18), dp(18))
        body.addView(fab, flp)
        root.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(hairline(), LinearLayout.LayoutParams(MATCH, 1))
        nav = LinearLayout(this)
        nav.setBackgroundColor(Col.NAV)
        root.addView(nav)
        setContentView(root)
        if (checkSelfPermission(perm()) != PackageManager.PERMISSION_GRANTED) askPermission()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putInt("tab", tab)
    }

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun askPermission() {
        val need = ArrayList<String>()
        need.add(perm())
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.READ_MEDIA_AUDIO)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    /** Re-reads the whole device library, so new videos appear automatically. */
    private fun refresh() {
        granted = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED
        if (!granted) { render(); return }
        Thread {
            val l = Library.scan(this)
            runOnUiThread { all = l.filter { !store.isHidden(it.id) }; render() }
        }.start()
    }

    private fun render() {
        nav.removeAllViews()
        val names = listOf("Home", "Folders", "Playlists", "History", "Settings")
        val icons = listOf(Ic.HOME, Ic.FOLDER, Ic.LIST, Ic.HISTORY, Ic.SETTINGS)
        for (i in 0..4) {
            val sel = i == tab
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.setPadding(0, dp(8), 0, dp(8))
            // Selected tab: accent icon on a soft pill, white label.
            val pill = FrameLayout(this)
            pill.background = rr(if (sel) Col.ACS else 0, dp(14).toFloat())
            pill.addView(iconView(icons[i], if (sel) Col.AC else Col.MU, 20), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            if (sel && slideDir != 0) {
                pill.scaleX = 0.7f
                pill.scaleY = 0.7f
                pill.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(3f)).start()
            }
            val plp = LinearLayout.LayoutParams(dp(56), dp(28))
            plp.gravity = Gravity.CENTER_HORIZONTAL
            item.addView(pill, plp)
            val label = tv(names[i], 10.5f, if (sel) Col.TX else Col.MU)
            label.gravity = Gravity.CENTER_HORIZONTAL
            label.setPadding(0, dp(3), 0, 0)
            item.addView(label, LinearLayout.LayoutParams(MATCH, WRAP))
            item.pressable(0.9f)
            item.setOnClickListener {
                if (i != tab) slideDir = if (i > tab) 1 else -1
                tab = i
                openFolder = null
                openPlaylist = null
                render()
            }
            nav.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        val dir = slideDir
        slideDir = 0
        // The screen that is currently showing slides/fades out while the new one slides/fades in.
        val old: View? = if (dir != 0 && content.childCount > 0) content.getChildAt(content.childCount - 1) else null
        for (k in content.childCount - 1 downTo 0) {
            val c = content.getChildAt(k)
            if (c !== old) {
                c.animate().cancel()
                content.removeViewAt(k)
            }
        }
        val v: View = when {
            !granted -> permView()
            tab == 0 -> homeView()
            tab == 1 -> recycler(folderRows())
            tab == 2 -> recycler(playlistRows())
            tab == 3 -> recycler(historyRows())
            else -> settingsView()
        }
        content.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        val hasLast = granted && tab != 4 && store.history().any { id -> all.any { it.id == id } }
        if (hasLast) fab.fadeIn() else fab.visibility = View.GONE
        if (dir != 0) {
            val shift = dp(32).toFloat() * dir
            if (old != null) {
                old.isEnabled = false
                old.animate().alpha(0f).translationX(-shift * 0.5f)
                    .setDuration(160).setInterpolator(DecelerateInterpolator())
                    .withEndAction { content.removeView(old) }.start()
            }
            v.alpha = 0f
            v.translationX = shift
            v.animate().alpha(1f).translationX(0f)
                .setDuration(280).setInterpolator(DecelerateInterpolator(2f)).start()
        }
    }

    private fun permView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(40), 0, dp(40), dp(24))
        val chip = FrameLayout(this)
        chip.background = rr(Col.CARD, dp(20).toFloat())
        chip.addView(iconView(Ic.VIDEO, Col.TX2, 30), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        col.addView(chip, LinearLayout.LayoutParams(dp(72), dp(72)))
        val h = tv("Allow video access", 18f, Col.TX, true)
        h.gravity = Gravity.CENTER
        val hlp = LinearLayout.LayoutParams(WRAP, WRAP)
        hlp.topMargin = dp(20)
        col.addView(h, hlp)
        val t = tv("NEXORA needs access to your videos to find and play them. Nothing leaves your device.", 14f, Col.MU)
        t.gravity = Gravity.CENTER
        t.setLineSpacing(0f, 1.15f)
        val tlp = LinearLayout.LayoutParams(WRAP, WRAP)
        tlp.topMargin = dp(8)
        col.addView(t, tlp)
        val b = tv("Allow access", 14f, Col.ON_AC, true)
        b.setPadding(dp(28), dp(12), dp(28), dp(12))
        b.background = rr(Col.AC, dp(12).toFloat())
        b.pressable(0.95f)
        b.setOnClickListener { askPermission() }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = dp(24)
        col.addView(b, lp)
        return col
    }

    private fun recycler(rows: List<Row>): RecyclerView {
        val span = maxOf(2, resources.displayMetrics.widthPixels / dp(170))
        val rv = RecyclerView(this)
        val lm = GridLayoutManager(this, span)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (rows[position] is Row.Vid) 1 else span
        }
        rv.layoutManager = lm
        rv.adapter = RowAdapter(this, rows, store, { list, i -> play(list, i) }, { v -> menu(v) })
        rv.setPadding(dp(11), 0, dp(11), dp(8))
        rv.clipToPadding = false
        return rv
    }

    private fun homeView(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val et = EditText(this)
        et.hint = "Search videos"
        et.setHintTextColor(Col.MU)
        et.setTextColor(Col.TX)
        et.textSize = 14f
        et.setSingleLine()
        et.background = rr(Col.CARD, dp(12).toFloat())
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        et.setCompoundDrawablesRelativeWithIntrinsicBounds(PathIcon(Ic.SEARCH, Col.MU, false, dp(18)), null, null, null)
        et.compoundDrawablePadding = dp(10)
        et.setText(query)
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s.toString()
                box.removeViewAt(1)
                box.addView(recycler(homeRows()), 1, LinearLayout.LayoutParams(MATCH, 0, 1f))
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(dp(16), dp(4), dp(16), dp(6))
        box.addView(et, lp)
        box.addView(recycler(homeRows()), LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun homeRows(): List<Row> {
        val l = all.filter { query.isBlank() || it.name.contains(query, true) }
        if (l.isEmpty()) return listOf(Row.Head(if (all.isEmpty()) "No videos found on this device." else "No videos match your search."))
        val rows = ArrayList<Row>()
        if (query.isBlank()) {
            val cont = l.filter { val p = store.pos(it.id); p > 5000 && it.durationMs > 0 && p < it.durationMs - 8000 }
            if (cont.isNotEmpty()) { rows.add(Row.Head("Continue watching")); cont.forEach { rows.add(Row.Vid(it, cont)) } }
            val favs = l.filter { store.isFav(it.id) }
            if (favs.isNotEmpty()) { rows.add(Row.Head("Favorites")); favs.forEach { rows.add(Row.Vid(it, favs)) } }
        }
        rows.add(Row.Head(if (query.isBlank()) "All videos" else "Results"))
        l.forEach { rows.add(Row.Vid(it, l)) }
        return rows
    }

    private fun backRow(label: String): Row =
        Row.Item(label, "", { slideDir = -1; openFolder = null; openPlaylist = null; render() }, null, Ic.BACK)

    private fun folderRows(): List<Row> {
        val groups = all.groupBy { it.folder }
        val open = openFolder
        if (open != null && groups.containsKey(open)) {
            val l = groups[open]!!
            val rows = ArrayList<Row>()
            rows.add(backRow(open))
            l.forEach { rows.add(Row.Vid(it, l)) }
            return rows
        }
        openFolder = null
        if (groups.isEmpty()) return listOf(Row.Head("No folders yet."))
        return groups.entries.sortedBy { it.key.lowercase() }.map { e ->
            Row.Item(e.key, "${e.value.size} videos", { slideDir = 1; openFolder = e.key; render() }, null, Ic.FOLDER)
        }
    }

    private fun playlistRows(): List<Row> {
        val open = openPlaylist
        if (open != null) {
            val l = store.playlist(open).mapNotNull { id -> all.firstOrNull { it.id == id } }
            val rows = ArrayList<Row>()
            rows.add(backRow(open))
            if (l.isEmpty()) rows.add(Row.Head("Empty. Use ⋯ on any video to add it here."))
            l.forEach { rows.add(Row.Vid(it, l)) }
            return rows
        }
        val rows = ArrayList<Row>()
        rows.add(Row.Item("New playlist", "", { newPlaylist(null) }, null, Ic.PLUS))
        store.playlistNames().forEach { n ->
            rows.add(Row.Item(n, "${store.playlist(n).size} videos", { slideDir = 1; openPlaylist = n; render() }, { deletePlaylist(n) }, Ic.LIST))
        }
        return rows
    }

    private fun historyRows(): List<Row> {
        val l = store.history().mapNotNull { id -> all.firstOrNull { it.id == id } }
        if (l.isEmpty()) return listOf(Row.Head("Nothing played yet."))
        val rows = ArrayList<Row>()
        rows.add(Row.Head("Recently played"))
        l.forEach { rows.add(Row.Vid(it, l)) }
        return rows
    }

    private fun speedLabel(f: Float): String = if (f % 1f == 0f) "${f.toInt()}x" else "${f}x"

    private fun themePicker(): View {
        val names = arrayOf("Dark", "Light", "System")
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(dp(12), dp(14), dp(12), dp(14))
        val t = tv("Theme", 14f)
        t.setPadding(dp(4), 0, 0, 0)
        wrap.addView(t)
        val sub = tv("Choose how NEXORA looks", 12f, Col.MU)
        sub.setPadding(dp(4), 0, 0, dp(12))
        wrap.addView(sub)
        val rowL = LinearLayout(this)
        for (i in 0..2) {
            val sel = store.theme == i
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(dp(4), dp(4), dp(4), dp(4))
            val prev = LinearLayout(this)
            prev.orientation = LinearLayout.HORIZONTAL
            prev.clipToOutline = true
            prev.background = rr(Col.CARD2, dp(12).toFloat(), if (sel) Col.AC else Col.LINE, if (sel) dp(2) else dp(1))
            fun half(bg: Int, bar: Int, w: Float) {
                val h = FrameLayout(this)
                h.setBackgroundColor(bg)
                val l1 = View(this); l1.background = rr(bar, dp(2).toFloat())
                val l2 = View(this); l2.background = rr(bar, dp(2).toFloat())
                val p1 = FrameLayout.LayoutParams(dp(26), dp(5), Gravity.TOP or Gravity.START)
                p1.setMargins(dp(10), dp(14), 0, 0)
                val p2 = FrameLayout.LayoutParams(dp(16), dp(5), Gravity.TOP or Gravity.START)
                p2.setMargins(dp(10), dp(26), 0, 0)
                h.addView(l1, p1); h.addView(l2, p2)
                prev.addView(h, LinearLayout.LayoutParams(0, MATCH, w))
            }
            when (i) {
                0 -> half(0xFF0A0A0B.toInt(), 0xFF3A3A42.toInt(), 1f)
                1 -> half(0xFFFFFFFF.toInt(), 0xFFCFCFD6.toInt(), 1f)
                else -> { half(0xFF0A0A0B.toInt(), 0xFF3A3A42.toInt(), 1f); half(0xFFFFFFFF.toInt(), 0xFFCFCFD6.toInt(), 1f) }
            }
            item.addView(prev, LinearLayout.LayoutParams(MATCH, dp(72)))
            val lab = tv(names[i], 12.5f, if (sel) Col.AC else Col.TX2, sel)
            lab.setPadding(0, dp(8), 0, 0)
            item.addView(lab)
            item.pressable(0.95f)
            item.setOnClickListener {
                if (store.theme != i) {
                    store.theme = i
                    Col.setup(this, i)
                    recreate()
                }
            }
            rowL.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        wrap.addView(rowL)
        return wrap
    }

    private fun settingsView(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(4), dp(16), dp(16))
        var group: LinearLayout? = null
        fun head(t: String) {
            val h = tv(t.uppercase(), 11.5f, Col.MU)
            h.letterSpacing = 0.08f
            h.setPadding(dp(4), dp(22), 0, dp(8))
            col.addView(h)
            val g = LinearLayout(this)
            g.orientation = LinearLayout.VERTICAL
            g.background = rr(Col.CARD, dp(12).toFloat())
            g.clipToOutline = true
            col.addView(g, LinearLayout.LayoutParams(MATCH, WRAP))
            group = g
        }
        fun row(t: String, sub: String, click: (() -> Unit)?, extra: View?) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(14), dp(13), dp(14), dp(13))
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(tv(t, 14f))
            if (sub.isNotEmpty()) tx.addView(tv(sub, 12f, Col.MU))
            r.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
            if (extra != null) r.addView(extra)
            if (click != null) {
                r.pressable(0.98f)
                r.setOnClickListener { click() }
            }
            val g = group ?: return
            if (g.childCount > 0) g.addView(hairline(), LinearLayout.LayoutParams(MATCH, 1))
            g.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        head("Appearance")
        group?.addView(themePicker())
        head("Playback")
        row("Default speed", speedLabel(store.speed), {
            val labels = speeds.map { speedLabel(it) }.toTypedArray()
            dialog().setTitle("Default speed")
                .setSingleChoiceItems(labels, speeds.indexOfFirst { it == store.speed }) { d, w -> store.speed = speeds[w]; d.dismiss(); render() }.show()
        }, null)
        row("Seek step", "${store.seekSec} seconds", {
            val labels = seekSteps.map { "$it seconds" }.toTypedArray()
            dialog().setTitle("Seek step")
                .setSingleChoiceItems(labels, seekSteps.indexOf(store.seekSec)) { d, w -> store.seekSec = seekSteps[w]; d.dismiss(); render() }.show()
        }, null)
        val sw = Switch(this)
        sw.isChecked = store.bgAudio
        val on = intArrayOf(android.R.attr.state_checked)
        sw.thumbTintList = ColorStateList(arrayOf(on, intArrayOf()), intArrayOf(Col.AC, Col.MU))
        sw.trackTintList = ColorStateList(arrayOf(on, intArrayOf()), intArrayOf(Col.SW_ON, Col.SW_OFF))
        sw.setOnCheckedChangeListener { _, c -> store.bgAudio = c }
        row("Background audio", "Keep playing when you leave the app", null, sw)
        head("Library")
        row("Rescan videos", "Videos are also found automatically", { refresh(); toast("Scanning…") }, null)
        head("Privacy")
        row("Clear playback history", "", { store.clearHistory(); toast("History cleared") }, null)
        row("Clear resume positions", "", { store.clearAllPos(); toast("Positions cleared") }, null)
        head("About")
        val about = tv("NEXORA 1.0\nPlay Everything. Experience More.\n\nVideos stay on your device and nothing is uploaded. Not in this version yet: equalizer, private vault, A-B repeat, Chromecast.", 12f, Col.MU)
        about.setPadding(dp(4), dp(8), dp(4), 0)
        col.addView(about)
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun dialog(): NxDialog = NxDialog(this)

    private fun toast(s: String) = snack(s)

    private fun menu(v: Video) {
        val fav = store.isFav(v.id)
        val items = arrayOf(if (fav) "Remove from favorites" else "Add to favorites", "Add to playlist", "Details")
        dialog().setTitle(v.title).setItems(items) { _, w ->
            if (w == 0) { store.toggleFav(v.id); render() }
            else if (w == 1) addToPlaylist(v)
            else dialog().setTitle("Details")
                .setMessage("${fmtSize(v.size)}   ${v.width}×${v.height}   ${fmtTime(v.durationMs)}\nFolder: ${v.folder}")
                .setPositiveButton("OK", null).show()
        }.show()
    }

    private fun addToPlaylist(v: Video) {
        val names = store.playlistNames()
        if (names.isEmpty()) { newPlaylist(v); return }
        dialog().setTitle("Add to playlist").setItems(names.toTypedArray()) { _, w ->
            store.addToPlaylist(names[w], v.id)
            toast("Added to ${names[w]}")
        }.show()
    }

    private fun newPlaylist(add: Video?) {
        val et = EditText(this)
        et.hint = "Playlist name"
        dialog().setTitle("New playlist").setView(et)
            .setPositiveButton("Create") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    store.createPlaylist(n)
                    if (add != null) store.addToPlaylist(n, add.id)
                    render()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deletePlaylist(n: String) {
        dialog().setTitle("Delete “$n”?")
            .setPositiveButton("Delete") { _, _ -> store.deletePlaylist(n); render() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun play(list: List<Video>, index: Int) {
        startActivity(PlayerActivity.intent(this, list, index))
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "video/*"
        @Suppress("DEPRECATION")
        startActivityForResult(i, 11)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val u: Uri = data?.data ?: return
        if (rc == 11 && res == RESULT_OK) {
            val v = Video(u.toString().hashCode().toLong(), queryName(u), "Files", 0, 0, 0, 0, u)
            play(listOf(v), 0)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (openFolder != null || openPlaylist != null) {
            slideDir = -1
            openFolder = null
            openPlaylist = null
            render()
        } else super.onBackPressed()
    }
}
