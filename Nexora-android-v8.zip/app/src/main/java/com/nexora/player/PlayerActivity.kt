@file:OptIn(UnstableApi::class)

package com.nexora.player

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : Activity() {
    companion object {
        fun intent(ctx: Context, list: List<Video>, index: Int): Intent {
            val start = maxOf(0, index - 100)
            val sub = list.subList(start, minOf(list.size, start + 200))
            val i = Intent(ctx, PlayerActivity::class.java)
            i.putStringArrayListExtra("uris", ArrayList(sub.map { it.uri.toString() }))
            i.putExtra("ids", sub.map { it.id }.toLongArray())
            i.putStringArrayListExtra("names", ArrayList(sub.map { it.title }))
            i.putExtra("index", index - start)
            return i
        }

        /** Light blue used for the seek bar and for "switched on" player buttons. */
        const val BLUE = 0xFF62B1F6.toInt()
        /** Dark translucent disc behind the round quick buttons. */
        const val DISC = 0xB3262626.toInt()
    }

    private lateinit var store: Store
    private lateinit var audio: AudioManager
    private lateinit var root: FrameLayout
    private lateinit var pv: PlayerView
    private lateinit var controls: FrameLayout
    private lateinit var title: TextView
    private lateinit var seek: HSeek
    private lateinit var tCur: TextView
    private lateinit var tDur: TextView
    private lateinit var btnPlay: ImageView
    private lateinit var speedBtn: TextView
    private lateinit var repeatBtn: ImageView
    private lateinit var hud: TextView
    private lateinit var unlock: TextView
    private lateinit var sBright: VSlider
    private lateinit var sVol: VSlider
    private lateinit var boxBright: View
    private lateinit var boxVol: View

    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private val ui = Handler(Looper.getMainLooper())
    private var items = mutableListOf<MediaItem>()
    private var ids = LongArray(0)
    private var names = ArrayList<String>()
    private var startIndex = 0
    private var locked = false
    private var dragging = false
    private var userRotated = false
    private var inPip = false
    /** Set by the headphones button: keep playing audio after the screen goes to the background. */
    private var keepAudio = false
    /** True while this screen starts another app screen (file picker, equalizer): that must not trigger picture-in-picture. */
    private var external = false
    private var vidW = 16
    private var vidH = 9
    private var resize = 0
    private var bright = 0.5f
    private var volF = 0.5f
    private var ticks = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Fit", "Fill screen (crop)", "Stretch")
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)

    private val hideRun = Runnable {
        if (controller?.isPlaying == true && !inPip) controls.fadeOut()
    }
    private val hudHide = Runnable { hud.visibility = View.GONE }
    private val sliderHide = Runnable {
        boxBright.visibility = View.GONE
        boxVol.visibility = View.GONE
    }
    private val unlockHide = Runnable { unlock.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null) {
                val dur = c.duration
                val pos = c.currentPosition
                if (dur > 0 && !dragging) seek.progress = (pos * 1000 / dur).toInt()
                if (!dragging) tCur.text = fmtTime(pos)
                tDur.text = if (dur > 0) fmtTime(dur) else "0:00"
                ticks++
                if (ticks % 6 == 0) savePos()
            }
            ui.postDelayed(this, 500)
        }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            btnPlay.setImageDrawable(PathIcon(if (isPlaying) Ic.PAUSE else Ic.PLAY, Color.WHITE, true, dp(44)))
            if (isPlaying) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                showControls()
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                ui.removeCallbacks(hideRun)
            }
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncTitle()
            currentId()?.let { store.addHistory(it) }
        }
        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            updateSpeedLabel()
        }
        override fun onRepeatModeChanged(repeatMode: Int) {
            syncRepeat()
        }
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                vidW = videoSize.width
                vidH = videoSize.height
            }
            if (!userRotated && videoSize.width > 0) {
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
        override fun onPlayerError(error: PlaybackException) {
            toast("This file can’t be played on this device. Try another format.")
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        Col.dark = true
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val data = intent.data
        val uris: List<String>
        if (intent.hasExtra("uris")) {
            uris = intent.getStringArrayListExtra("uris") ?: ArrayList()
            ids = intent.getLongArrayExtra("ids") ?: LongArray(0)
            names = intent.getStringArrayListExtra("names") ?: ArrayList()
            startIndex = intent.getIntExtra("index", 0)
        } else if (data != null) {
            uris = listOf(data.toString())
            ids = longArrayOf(data.toString().hashCode().toLong())
            names = arrayListOf(cleanName(queryName(data)))
        } else {
            finish()
            return
        }
        if (uris.isEmpty() || ids.size != uris.size || names.size != uris.size || startIndex !in uris.indices) {
            finish()
            return
        }
        items = uris.indices.map { i ->
            MediaItem.Builder()
                .setUri(Uri.parse(uris[i]))
                .setMediaId(ids[i].toString())
                .setMediaMetadata(MediaMetadata.Builder().setTitle(names[i]).build())
                .build()
        }.toMutableList()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val wic = WindowInsetsControllerCompat(window, window.decorView)
        wic.hide(WindowInsetsCompat.Type.systemBars())
        wic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp

        volF = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        // start the brightness slider from the real screen brightness, so the first swipe does not make the screen jump
        bright = try {
            (Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f).coerceIn(0.05f, 1f)
        } catch (e: Exception) {
            0.5f
        }
        buildUi()
    }

    private fun disc(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    /** Plain white icon button (no background). */
    private fun ib(path: String, sizeDp: Int, padDp: Int = 10, filled: Boolean = false, onClick: () -> Unit): ImageView {
        val v = iconView(path, Color.WHITE, sizeDp, filled)
        v.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
        v.pressable(0.85f)
        v.setOnClickListener { onClick() }
        return v
    }

    /** Round dark button used in the quick-action row under the title. */
    private fun roundBtn(path: String, filled: Boolean = false, onClick: () -> Unit): ImageView {
        val v = iconView(path, Color.WHITE, 22, filled)
        v.setPadding(dp(9), dp(9), dp(9), dp(9))
        v.background = disc(DISC)
        v.pressable(0.88f)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun gap(startDp: Int, w: Int = WRAP, h: Int = WRAP): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.marginStart = dp(startDp)
        return lp
    }

    private fun sliderBox(s: VSlider, icon: String): View {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.gravity = Gravity.CENTER_HORIZONTAL
        b.background = rr(0x59000000, dp(22).toFloat())
        b.setPadding(dp(8), dp(12), dp(8), dp(12))
        b.addView(s, LinearLayout.LayoutParams(dp(30), dp(120)))
        val ic = iconView(icon, Color.WHITE, 18)
        ic.setPadding(0, dp(8), 0, 0)
        b.addView(ic, LinearLayout.LayoutParams(WRAP, WRAP))
        return b
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.useController = false
        root.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
        controls = FrameLayout(this)
        root.addView(controls, FrameLayout.LayoutParams(MATCH, MATCH))

        // keep the left/right controls clear of a display cut-out (notch)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.systemBars())
            controls.setPadding(bars.left, 0, bars.right, 0)
            insets
        }

        // ---- top area: [back  title  audio  subtitles  HW  more] + quick-action row below ----
        val topBox = LinearLayout(this)
        topBox.orientation = LinearLayout.VERTICAL
        topBox.setPadding(dp(14), dp(6), dp(14), dp(28))
        topBox.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xB8000000.toInt(), 0x00000000))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = ib(Ic.BACK, 24) { finish() }
        title = tv("", 16f, Color.WHITE, true)
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        val audioBtn = ib(Ic.NOTE, 22, filled = true) { audioDialog(); showControls() }
        val subBtn = ib(Ic.SUBTITLES, 24) { subDialog(); showControls() }
        val hw = tv("HW", 14f, Color.WHITE, true)
        hw.setPadding(dp(10), dp(10), dp(10), dp(10))
        hw.pressable(0.85f)
        hw.setOnClickListener { toast("Hardware decoding is on"); showControls() }
        val more = ib(Ic.MORE, 24, filled = true) { showMenu() }
        top.addView(back)
        top.addView(title, gap(4, 0, WRAP).also { it.weight = 1f })
        top.addView(audioBtn)
        top.addView(subBtn)
        top.addView(hw)
        top.addView(more)
        topBox.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        // quick actions: equalizer, speed, screenshot, background audio, rotate, [>] more
        val quick = LinearLayout(this)
        quick.gravity = Gravity.CENTER_VERTICAL
        val eq = roundBtn(Ic.EQ, filled = true) { openEqualizer(); showControls() }
        speedBtn = tv("1X", 18f, Color.WHITE, true)
        speedBtn.gravity = Gravity.CENTER
        speedBtn.setPadding(dp(14), 0, dp(14), 0)
        speedBtn.pressable(0.88f)
        speedBtn.setOnClickListener { speedDialog(); showControls() }
        val shot = roundBtn(Ic.SHOT) { takeShot(); showControls() }
        val phones = roundBtn(Ic.HEADPHONES) {
            keepAudio = true
            toast("Playing in background")
            moveTaskToBack(true)
        }
        val rot = roundBtn(Ic.ROTATE_SCREEN) {
            userRotated = true
            val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            showControls()
        }
        repeatBtn = roundBtn(Ic.REPEAT) { toggleRepeat(); showControls() }
        val sleep = roundBtn(Ic.MOON) { sleepDialog(); showControls() }
        val extras = listOf<View>(repeatBtn, sleep)
        extras.forEach { it.visibility = View.GONE }
        val chev = iconView(Ic.CHEVRON, Color.WHITE, 16)
        chev.setPadding(dp(6), dp(6), dp(6), dp(6))
        chev.background = disc(DISC)
        chev.pressable(0.88f)
        chev.setOnClickListener {
            val open = extras[0].visibility != View.VISIBLE
            extras.forEach { it.visibility = if (open) View.VISIBLE else View.GONE }
            chev.animate().rotation(if (open) 180f else 0f).setDuration(180).start()
            showControls()
        }
        quick.addView(eq, gap(0, dp(40), dp(40)))
        quick.addView(speedBtn, gap(4, WRAP, dp(40)))
        quick.addView(shot, gap(4, dp(40), dp(40)))
        quick.addView(phones, gap(12, dp(40), dp(40)))
        quick.addView(rot, gap(12, dp(40), dp(40)))
        quick.addView(chev, gap(12, dp(28), dp(28)))
        quick.addView(repeatBtn, gap(12, dp(40), dp(40)))
        quick.addView(sleep, gap(12, dp(40), dp(40)))
        val quickScroll = HorizontalScrollView(this)
        quickScroll.isHorizontalScrollBarEnabled = false
        quickScroll.overScrollMode = View.OVER_SCROLL_NEVER
        quickScroll.addView(quick)
        topBox.addView(quickScroll, gap(4, WRAP, WRAP).also { it.topMargin = dp(8) })
        controls.addView(topBox, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        // side sliders
        sBright = VSlider(this)
        sVol = VSlider(this)
        sBright.value = bright
        sVol.value = volF
        sBright.onChange = { setBrightness(it) }
        sVol.onChange = { setVolume(it) }
        // sliders stay hidden; they appear only while brightness/volume is being changed
        boxBright = sliderBox(sBright, Ic.SUN)
        boxVol = sliderBox(sVol, Ic.VOLUME)
        boxBright.visibility = View.GONE
        boxVol.visibility = View.GONE
        val lpB = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL)
        lpB.marginStart = dp(28)
        root.addView(boxBright, lpB)
        val lpV = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL)
        lpV.marginEnd = dp(28)
        root.addView(boxVol, lpV)

        // ---- bottom area: [time  seek bar  duration] then [lock | prev play next | aspect  PiP] ----
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(20), dp(36), dp(20), dp(8))
        bottom.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xE6000000.toInt()))
        val timeRow = LinearLayout(this)
        timeRow.gravity = Gravity.CENTER_VERTICAL
        tCur = tv("0:00", 14f, Color.WHITE)
        tDur = tv("0:00", 14f, Color.WHITE)
        tCur.minWidth = dp(44)
        tDur.minWidth = dp(44)
        tCur.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        tDur.gravity = Gravity.CENTER_VERTICAL or Gravity.END
        seek = HSeek(this)
        seek.setColors(BLUE, BLUE)
        seek.onStart = { dragging = true }
        seek.onChange = { p ->
            val d = controller?.duration ?: 0L
            if (d > 0) tCur.text = fmtTime(d * p / 1000)
        }
        seek.onStop = { p ->
            dragging = false
            val c = controller
            if (c != null && c.duration > 0) c.seekTo(c.duration * p / 1000)
        }
        timeRow.addView(tCur)
        timeRow.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
        timeRow.addView(tDur)
        bottom.addView(timeRow)

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val lock = ib(Ic.LOCK, 26) { locked = true; controls.fadeOut(); toast("Controls locked") }
        val prev = ib(Ic.PREV, 30, filled = true) { step(-1); showControls() }
        btnPlay = ib(Ic.PLAY, 44, 10, true) { togglePlay() }
        val next = ib(Ic.NEXT, 30, filled = true) { step(1); showControls() }
        val aspect = ib(Ic.ASPECT, 28) {
            resize = (resize + 1) % resizeModes.size
            pv.resizeMode = resizeModes[resize]
            hudShow(resizeNames[resize])
            showControls()
        }
        val pip = ib(Ic.PIP, 28) { enterPip() }

        // left and right groups share the free space equally, so prev / play / next stay centred
        val leftGroup = LinearLayout(this)
        leftGroup.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        leftGroup.addView(lock)
        val centerGroup = LinearLayout(this)
        centerGroup.gravity = Gravity.CENTER_VERTICAL
        centerGroup.addView(prev)
        centerGroup.addView(btnPlay, gap(22))
        centerGroup.addView(next, gap(22))
        val rightGroup = LinearLayout(this)
        rightGroup.gravity = Gravity.CENTER_VERTICAL or Gravity.END
        rightGroup.addView(aspect)
        rightGroup.addView(pip, gap(8))
        row.addView(leftGroup, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(centerGroup, LinearLayout.LayoutParams(WRAP, WRAP))
        row.addView(rightGroup, LinearLayout.LayoutParams(0, WRAP, 1f))
        bottom.addView(row)
        controls.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        // narrow screens (portrait): tighter spacing so the bottom buttons never overlap
        val bottomBtns = listOf(lock, prev, btnPlay, next, aspect, pip)
        var compact = false
        fun fit(narrow: Boolean) {
            val p = dp(if (narrow) 6 else 10)
            bottomBtns.forEach { it.setPadding(p, p, p, p) }
            (btnPlay.layoutParams as LinearLayout.LayoutParams).marginStart = dp(if (narrow) 6 else 22)
            (next.layoutParams as LinearLayout.LayoutParams).marginStart = dp(if (narrow) 6 else 22)
            (pip.layoutParams as LinearLayout.LayoutParams).marginStart = dp(if (narrow) 4 else 8)
            bottom.setPadding(dp(if (narrow) 12 else 20), dp(36), dp(if (narrow) 12 else 20), dp(8))
            row.requestLayout()
        }
        root.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val narrow = (r - l) < dp(560)
            if (narrow != compact) {
                compact = narrow
                root.post { fit(narrow) }
            }
        }

        // HUD and unlock
        hud = tv("", 16f, Color.WHITE, true)
        hud.setPadding(dp(18), dp(10), dp(18), dp(10))
        hud.background = rr(0xAA000000.toInt(), dp(10).toFloat())
        hud.visibility = View.GONE
        root.addView(hud, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        unlock = tv("Tap to unlock", 14f, 0xFF0B0B0B.toInt(), true)
        unlock.setPadding(dp(20), dp(10), dp(20), dp(10))
        unlock.background = rr(Col.AC, dp(20).toFloat())
        unlock.visibility = View.GONE
        unlock.pressable(0.92f)
        unlock.setOnClickListener { locked = false; unlock.visibility = View.GONE; showControls() }
        val ulp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        ulp.bottomMargin = dp(40)
        root.addView(unlock, ulp)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    unlock.visibility = View.VISIBLE
                    ui.removeCallbacks(unlockHide)
                    ui.postDelayed(unlockHide, 2500)
                } else if (controls.visibility == View.VISIBLE && controls.alpha > 0.5f) controls.fadeOut()
                else showControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = root.width
                if (e.x < w / 3f) seekBy(-store.seekSec * 1000L)
                else if (e.x > w * 2 / 3f) seekBy(store.seekSec * 1000L)
                else togglePlay()
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || abs(dy) < abs(dx)) return false
                val d = dy / root.height * 1.2f
                if (e1.x < root.width / 2f) setBrightness(bright + d) else setVolume(volF + d)
                return true
            }
        })
        root.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
        setContentView(root)
    }

    private fun toast(s: String) = snack(s)

    /** "1X", "1.5X", "0.25X" - always shows the real speed of the player. */
    private fun updateSpeedLabel() {
        val s = controller?.playbackParameters?.speed ?: 1f
        speedBtn.text = (if (s % 1f == 0f) s.toInt().toString() else s.toString()) + "X"
    }

    private fun syncRepeat() {
        val on = (controller?.repeatMode ?: Player.REPEAT_MODE_OFF) != Player.REPEAT_MODE_OFF
        repeatBtn.setImageDrawable(PathIcon(Ic.REPEAT, if (on) BLUE else Color.WHITE, false, dp(22)))
    }

    private fun toggleRepeat() {
        val c = controller ?: return
        val on = c.repeatMode == Player.REPEAT_MODE_OFF
        c.repeatMode = if (on) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        hudShow(if (on) "Repeat: this video" else "Repeat: off")
    }

    private fun openEqualizer() {
        val i = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
        i.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
        i.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, PlaybackService.audioSession)
        i.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MOVIE)
        external = true
        try {
            startActivity(i)
        } catch (e: Exception) {
            external = false
            toast("No equalizer found on this phone")
        }
    }

    /** Saves the frame that is on screen to Pictures/Nexora. */
    private fun takeShot() {
        val v = pv.videoSurfaceView
        if (v == null || v.width <= 0 || v.height <= 0) {
            toast("Nothing to capture yet")
            return
        }
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        try {
            if (v is SurfaceView) {
                PixelCopy.request(v, bmp, PixelCopy.OnPixelCopyFinishedListener { r ->
                    if (r == PixelCopy.SUCCESS) saveShot(bmp) else toast("Couldn’t capture this frame")
                }, ui)
            } else if (v is TextureView) {
                saveShot(v.getBitmap(bmp))
            } else {
                toast("Couldn’t capture this frame")
            }
        } catch (e: Exception) {
            toast("Couldn’t capture this frame")
        }
    }

    private fun saveShot(bmp: Bitmap) {
        Thread {
            val ok = try {
                val name = "Nexora_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Nexora")
                cv.put(MediaStore.Images.Media.IS_PENDING, 1)
                val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (u == null) {
                    false
                } else {
                    contentResolver.openOutputStream(u)?.use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 95, out) }
                    val done = ContentValues()
                    done.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(u, done, null, null)
                    true
                }
            } catch (e: Exception) {
                false
            }
            runOnUiThread { toast(if (ok) "Screenshot saved to Pictures/Nexora" else "Couldn’t save the screenshot") }
        }.start()
    }

    private fun sliderShow(box: View) {
        box.visibility = View.VISIBLE
        ui.removeCallbacks(sliderHide)
        ui.postDelayed(sliderHide, 1500)
    }

    private fun hudShow(s: String) {
        hud.text = s
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hudHide)
        ui.postDelayed(hudHide, 900)
    }

    private fun showControls() {
        if (locked || inPip) return
        controls.fadeIn()
        ui.removeCallbacks(hideRun)
        ui.postDelayed(hideRun, 3500)
    }

    private fun setBrightness(v: Float) {
        bright = v.coerceIn(0.05f, 1f)
        val lp = window.attributes
        lp.screenBrightness = bright
        window.attributes = lp
        sBright.value = bright
        sliderShow(boxBright)
        hudShow("Brightness ${(bright * 100).toInt()}%")
    }

    private fun setVolume(v: Float) {
        volF = v.coerceIn(0f, 1f)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volF * max).roundToInt(), 0)
        sVol.value = volF
        sliderShow(boxVol)
        hudShow("Volume ${(volF * 100).toInt()}%")
    }

    private fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    private fun seekBy(ms: Long) {
        val c = controller ?: return
        val d = c.duration
        val t = c.currentPosition + ms
        c.seekTo(if (d > 0) t.coerceIn(0L, d) else maxOf(0L, t))
        hudShow((if (ms > 0) "+" else "−") + abs(ms / 1000) + " s")
    }

    private fun step(dir: Int) {
        val c = controller ?: return
        if (dir > 0) { if (c.hasNextMediaItem()) c.seekToNextMediaItem() else toast("End of queue") }
        else { if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem() else toast("Start of queue") }
    }

    private fun currentId(): Long? = ids.getOrNull(controller?.currentMediaItemIndex ?: -1)

    private fun syncTitle() {
        title.text = names.getOrNull(controller?.currentMediaItemIndex ?: startIndex) ?: ""
    }

    private fun savePos() {
        val c = controller ?: return
        val id = currentId() ?: return
        val dur = c.duration
        val pos = c.currentPosition
        if (dur > 0 && pos > dur - 3000) store.clearPos(id) else if (pos > 3000) store.savePos(id, pos)
    }

    override fun onStart() {
        super.onStart()
        keepAudio = false
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try { onConnected(f.get()) } catch (e: Exception) { toast("Couldn’t start the player") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onConnected(c: MediaController) {
        controller = c
        pv.player = c
        c.addListener(listener)
        val same = c.currentMediaItem?.mediaId == ids[startIndex].toString() && c.mediaItemCount == items.size
        if (!same) {
            val pos = store.pos(ids[startIndex])
            c.setPlaybackSpeed(store.speed)
            c.setMediaItems(items, startIndex, if (pos > 5000) pos else 0L)
            c.prepare()
            c.play()
            store.addHistory(ids[startIndex])
        }
        syncTitle()
        updateSpeedLabel()
        syncRepeat()
        listener.onIsPlayingChanged(c.isPlaying)
        ui.removeCallbacks(tick)
        ui.post(tick)
        showControls()
    }

    override fun onResume() {
        super.onResume()
        external = false
        Col.dark = true
    }

    override fun onPause() {
        super.onPause()
        Col.setup(this, store.theme)
    }

    override fun onStop() {
        super.onStop()
        savePos()
        ui.removeCallbacks(tick)
        if (!store.bgAudio && !keepAudio) controller?.pause()
        controller?.removeListener(listener)
        pv.player = null
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        if (controller?.isPlaying == true && !locked && !keepAudio && !external) enterPip()
    }

    private fun enterPip() {
        try {
            // follow the real video shape (Android only accepts ratios between about 1:2.39 and 2.39:1)
            val r = (vidW.toFloat() / vidH).coerceIn(0.42f, 2.39f)
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational((r * 1000).toInt(), 1000)).build())
        } catch (e: Exception) {
            toast("Picture-in-picture isn’t available")
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        controls.visibility = if (inPip) View.GONE else View.VISIBLE
        if (!inPip) showControls()
    }

    // ---- menu ----
    private fun dlg(): NxDialog = NxDialog(this)

    private fun showMenu() {
        showControls()
        val labels = arrayOf("Playback speed", "Aspect ratio", "Audio track", "Subtitles", "Sleep timer", "Picture in picture")
        dlg().setItems(labels) { _, i ->
            when (i) {
                0 -> speedDialog()
                1 -> aspectDialog()
                2 -> audioDialog()
                3 -> subDialog()
                4 -> sleepDialog()
                else -> enterPip()
            }
        }.show()
    }

    private fun speedDialog() {
        val c = controller ?: return
        val labels = speeds.map { if (it % 1f == 0f) "${it.toInt()}x" else "${it}x" }.toTypedArray()
        dlg().setTitle("Playback speed")
            .setSingleChoiceItems(labels, speeds.indexOfFirst { it == c.playbackParameters.speed }) { d, w ->
                c.setPlaybackSpeed(speeds[w])
                d.dismiss()
            }.show()
    }

    private fun aspectDialog() {
        dlg().setTitle("Aspect ratio").setSingleChoiceItems(resizeNames, resize) { d, w ->
            resize = w
            pv.resizeMode = resizeModes[w]
            d.dismiss()
        }.show()
    }

    private fun audioDialog() {
        val c = controller ?: return
        val groups = c.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        if (groups.isEmpty()) { toast("No audio tracks found"); return }
        val labels = groups.mapIndexed { i, g ->
            val f = g.getTrackFormat(0)
            (f.label ?: f.language ?: "Track ${i + 1}") + (if (g.isSelected) "   ✓" else "")
        }.toTypedArray()
        dlg().setTitle("Audio track").setItems(labels) { _, w ->
            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                .setOverrideForType(TrackSelectionOverride(groups[w].mediaTrackGroup, 0)).build()
        }.show()
    }

    private fun setTextDisabled(off: Boolean) {
        val c = controller ?: return
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, off).build()
    }

    private fun subDialog() {
        dlg().setTitle("Subtitles").setItems(arrayOf("Load subtitle file (.srt, .vtt)", "Turn off", "Turn on")) { _, w ->
            if (w == 0) {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                external = true
                @Suppress("DEPRECATION")
                startActivityForResult(i, 21)
            } else setTextDisabled(w == 1)
        }.show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val u = data?.data ?: return
        if (rc == 21 && res == RESULT_OK) applySub(u)
    }

    private fun applySub(u: Uri) {
        val c = controller ?: return
        val idx = c.currentMediaItemIndex
        val n = queryName(u).lowercase()
        val mime = if (n.endsWith(".srt")) MimeTypes.APPLICATION_SUBRIP
        else if (n.endsWith(".ass") || n.endsWith(".ssa")) MimeTypes.TEXT_SSA
        else MimeTypes.TEXT_VTT
        val sub = MediaItem.SubtitleConfiguration.Builder(u)
            .setMimeType(mime).setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        items[idx] = items[idx].buildUpon().setSubtitleConfigurations(listOf(sub)).build()
        val pos = c.currentPosition
        val was = c.isPlaying
        c.setMediaItems(items, idx, pos)
        c.prepare()
        if (was) c.play()
        toast("Subtitles loaded")
    }

    private fun sleepDialog() {
        val mins = intArrayOf(15, 30, 60, 0)
        val labels = arrayOf("15 minutes", "30 minutes", "60 minutes", "Off")
        dlg().setTitle("Sleep timer").setItems(labels) { _, w ->
            ui.removeCallbacks(sleepRun)
            if (mins[w] > 0) {
                ui.postDelayed(sleepRun, mins[w] * 60_000L)
                toast("Will pause in ${mins[w]} minutes")
            } else toast("Sleep timer off")
        }.show()
    }

    private val sleepRun = Runnable { controller?.pause(); toast("Sleep timer: paused") }
}
