package com.nexora.player

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.min

/** Scroll view that never grows taller than [maxH]. */
class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/**
 * NEXORA's own dialog. Same call style as AlertDialog.Builder, but:
 *  - a list of choices (setItems / setSingleChoiceItems) opens as a bottom sheet,
 *  - anything with a message, input field or buttons opens as a centered rounded card.
 */
class NxDialog(private val ctx: Context) {
    private var title: CharSequence? = null
    private var message: CharSequence? = null
    private var view: View? = null
    private var labels: Array<out CharSequence>? = null
    private var checked = -1
    private var onPick: ((DialogInterface, Int) -> Unit)? = null
    private var posText: CharSequence? = null
    private var posCb: ((DialogInterface, Int) -> Unit)? = null
    private var negText: CharSequence? = null
    private var negCb: ((DialogInterface, Int) -> Unit)? = null

    fun setTitle(t: CharSequence?): NxDialog { title = t; return this }
    fun setMessage(m: CharSequence?): NxDialog { message = m; return this }
    fun setView(v: View): NxDialog { view = v; return this }
    fun setItems(l: Array<out CharSequence>, cb: ((DialogInterface, Int) -> Unit)?): NxDialog {
        labels = l
        onPick = cb
        return this
    }
    fun setSingleChoiceItems(l: Array<out CharSequence>, selected: Int, cb: ((DialogInterface, Int) -> Unit)?): NxDialog {
        labels = l
        checked = selected
        onPick = cb
        return this
    }
    fun setPositiveButton(t: CharSequence, cb: ((DialogInterface, Int) -> Unit)?): NxDialog {
        posText = t
        posCb = cb
        return this
    }
    fun setNegativeButton(t: CharSequence, cb: ((DialogInterface, Int) -> Unit)?): NxDialog {
        negText = t
        negCb = cb
        return this
    }

    fun show(): Dialog {
        val l = labels
        val sheet = l != null
        val d = Dialog(ctx, R.style.NexoraSheet)
        val dm = ctx.resources.displayMetrics
        val r = ctx.dp(22).toFloat()

        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Col.SHEET)
        bg.setStroke(ctx.dp(1), Col.LINE)
        bg.cornerRadii = if (sheet) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else floatArrayOf(r, r, r, r, r, r, r, r)
        card.background = bg
        if (sheet) card.setPadding(0, 0, 0, ctx.dp(8))

        if (sheet) {
            val handle = View(ctx)
            handle.background = rr(Col.HANDLE, ctx.dp(2).toFloat())
            val hlp = LinearLayout.LayoutParams(ctx.dp(36), ctx.dp(4))
            hlp.gravity = Gravity.CENTER_HORIZONTAL
            hlp.topMargin = ctx.dp(10)
            card.addView(handle, hlp)
        }

        val tt = title
        if (tt != null) {
            val t = ctx.tv(tt.toString(), if (sheet) 15f else 18f, if (sheet) Col.TX2 else Col.TX, true)
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(ctx.dp(24), ctx.dp(if (sheet) 14 else 24), ctx.dp(24), ctx.dp(if (sheet) 6 else 8))
            card.addView(t)
        }

        val mm = message
        if (mm != null) {
            val t = ctx.tv(mm.toString(), 14f, Col.TX2)
            t.setLineSpacing(0f, 1.2f)
            t.setPadding(ctx.dp(24), ctx.dp(4), ctx.dp(24), ctx.dp(8))
            card.addView(t)
        }

        val v = view
        if (v != null) {
            if (v is EditText) {
                v.background = rr(Col.CARD2, ctx.dp(10).toFloat())
                v.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
                v.setTextColor(Col.TX)
                v.setHintTextColor(Col.MU)
                v.textSize = 15f
            }
            val vlp = LinearLayout.LayoutParams(MATCH, WRAP)
            vlp.setMargins(ctx.dp(24), ctx.dp(8), ctx.dp(24), ctx.dp(8))
            card.addView(v, vlp)
        }

        if (l != null) {
            val list = LinearLayout(ctx)
            list.orientation = LinearLayout.VERTICAL
            list.setPadding(0, ctx.dp(4), 0, ctx.dp(8))
            for (i in l.indices) {
                val sel = i == checked
                val row = LinearLayout(ctx)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(ctx.dp(24), ctx.dp(15), ctx.dp(24), ctx.dp(15))
                row.background = RippleDrawable(ColorStateList.valueOf(Col.RIPPLE), null, ColorDrawable(Color.WHITE))
                val t = ctx.tv(l[i].toString(), 15f, if (sel) Col.AC else Col.TX, sel)
                t.maxLines = 2
                t.ellipsize = TextUtils.TruncateAt.END
                row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
                if (sel) row.addView(ctx.iconView(Ic.CHECK, Col.AC, 20))
                row.setOnClickListener {
                    d.dismiss()
                    onPick?.invoke(d, i)
                }
                list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            }
            val sv = MaxHeightScroll(ctx, (dm.heightPixels * 0.6f).toInt())
            sv.addView(list)
            card.addView(sv, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val pt = posText
        val nt = negText
        if (pt != null || nt != null) {
            val bar = LinearLayout(ctx)
            bar.gravity = Gravity.END
            bar.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(16), ctx.dp(14))
            if (nt != null) {
                val b = ctx.tv(nt.toString(), 14f, Col.TX2, true)
                b.setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
                b.pressable(0.95f)
                b.setOnClickListener {
                    d.dismiss()
                    negCb?.invoke(d, DialogInterface.BUTTON_NEGATIVE)
                }
                bar.addView(b)
            }
            if (pt != null) {
                val b = ctx.tv(pt.toString(), 14f, Col.AC, true)
                b.setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
                b.pressable(0.95f)
                b.setOnClickListener {
                    d.dismiss()
                    posCb?.invoke(d, DialogInterface.BUTTON_POSITIVE)
                }
                bar.addView(b)
            }
            card.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        d.setContentView(card)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val width = min(dm.widthPixels - (if (sheet) 0 else ctx.dp(32)), ctx.dp(if (sheet) 480 else 400))
            w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
            w.setGravity(if (sheet) (Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL) else Gravity.CENTER)
            w.setWindowAnimations(if (sheet) R.style.NexoraSheetAnim else R.style.NexoraPopAnim)
            if (v != null) {
                w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
        }
        d.setCanceledOnTouchOutside(true)
        d.show()
        return d
    }
}

/** Small floating message pill, replaces the system Toast. */
fun Activity.snack(msg: String) {
    val host = findViewById<FrameLayout>(android.R.id.content)
    val t = tv(msg, 13.5f, Col.SNACK_TX)
    t.setPadding(dp(18), dp(12), dp(18), dp(12))
    t.background = rr(Col.SNACK, dp(24).toFloat(), Col.LINE, dp(1))
    t.elevation = dp(6).toFloat()
    t.maxWidth = dp(420)
    val lp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
    lp.bottomMargin = dp(96)
    host.addView(t, lp)
    t.alpha = 0f
    t.translationY = dp(16).toFloat()
    t.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator())
        .withEndAction {
            t.animate().alpha(0f).setStartDelay(1900).setDuration(240)
                .withEndAction { host.removeView(t) }.start()
        }.start()
}
