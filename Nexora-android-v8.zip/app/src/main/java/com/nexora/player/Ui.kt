package com.nexora.player

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.PathParser

const val MATCH = -1
const val WRAP = -2

object Col {
    /** True while the dark (black) palette is active. */
    var dark = true

    /** mode: 0 = Dark, 1 = Light, 2 = follow the phone's setting. */
    fun setup(ctx: Context, mode: Int) {
        dark = when (mode) {
            1 -> false
            2 -> (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES
            else -> true
        }
    }

    val BG get() = if (dark) 0xFF0A0A0B.toInt() else 0xFFFFFFFF.toInt()
    val NAV get() = if (dark) 0xFF0E0E10.toInt() else 0xFFFFFFFF.toInt()
    val CARD get() = if (dark) 0xFF141416.toInt() else 0xFFF4F4F5.toInt()
    val CARD2 get() = if (dark) 0xFF1E1E21.toInt() else 0xFFE8E8EA.toInt()
    val LINE get() = if (dark) 0xFF2A2A2E.toInt() else 0xFFE0E0E3.toInt()
    val AC get() = if (dark) 0xFFFFFFFF.toInt() else 0xFF141416.toInt()
    val ACS get() = if (dark) 0x26FFFFFF else 0x14141416
    val TX get() = if (dark) 0xFFEDEDEF.toInt() else 0xFF111114.toInt()
    val TX2 get() = if (dark) 0xFFB4B4BC.toInt() else 0xFF4A4A52.toInt()
    val MU get() = if (dark) 0xFF84848C.toInt() else 0xFF787882.toInt()
    /** Text/icon colour drawn on top of the accent colour. */
    val ON_AC get() = if (dark) 0xFF0A0A0B.toInt() else 0xFFFFFFFF.toInt()
    /** Dialog / bottom sheet surface. */
    val SHEET get() = if (dark) 0xFF18181B.toInt() else 0xFFFFFFFF.toInt()
    val SNACK get() = if (dark) 0xF21E1E22.toInt() else 0xF2222226.toInt()
    val SNACK_TX get() = 0xFFFFFFFF.toInt()
    val RIPPLE get() = if (dark) 0x22FFFFFF else 0x14000000
    val HANDLE get() = if (dark) 0x40FFFFFF else 0x30000000
    val SW_ON get() = if (dark) 0x80FFFFFF.toInt() else 0x80141416.toInt()
    val SW_OFF get() = if (dark) 0x40FFFFFF else 0x33000000
}

/** Paints status bar, navigation bar and window background to match the current theme. */
fun android.app.Activity.applyBars() {
    window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Col.BG))
    window.statusBarColor = Col.BG
    window.navigationBarColor = Col.NAV
    val c = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
    c.isAppearanceLightStatusBars = !Col.dark
    c.isAppearanceLightNavigationBars = !Col.dark
}

object Ic {
    const val HOME = "M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"
    const val FOLDER = "M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
    const val LIST = "M4 6h12M4 11h12M4 16h8M18 14v6l4-3z"
    const val HISTORY = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 7v5l3 2"
    const val SETTINGS = "M4 7h10M18 7h2M4 17h2M10 17h10M16 5a2 2 0 1 0 0 4a2 2 0 1 0 0-4zM8 15a2 2 0 1 0 0 4a2 2 0 1 0 0-4z"
    const val SUN = "M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8zM12 2.5v2M12 19.5v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2.5 12h2M19.5 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"
    const val VOLUME = "M4 9.5v5h3.5L12 18.5v-13L7.5 9.5zM15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"
    const val CHECK = "M5 12.5l4.5 4.5L19 7"
    const val PLUS = "M12 5v14M5 12h14"
    const val PLAY = "M7 4.5v15l12-7.5z"
    const val PAUSE = "M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"
    const val BACK = "M15 5l-7 7 7 7"
    const val PREV = "M6 5v14M19 5L9 12l10 7z"
    const val NEXT = "M18 5v14M5 5l10 7-10 7z"
    const val LOCK = "M7 11h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zM8 11V8a4 4 0 0 1 8 0v3"
    const val ROTATE = "M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3M18 3v4h-4M6 21v-4h4"
    const val CHEVRON = "M9 5l7 7-7 7"
    const val VIDEO = "M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM10 8.5v7l5.5-3.5z"
    const val MUSIC = "M9 18V6l10-2v12M9 18a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0zM19 16a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0z"
    const val DOWNLOAD = "M12 4v11M7 11l5 5 5-5M5 20h14"
    const val STAR = "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"
    const val PHONE = "M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM11 18h2"
    const val TRASH = "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"
    const val SEARCH = "M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14zM16 16l5 5"
    const val MORE = "M12 3.5a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3zM12 10.5a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3zM12 17.5a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3z"

    // ---- video player icons ----
    /** Equalizer: three sliders (draw filled). */
    const val EQ = "M6 4v16M12 4v16M18 4v16M3.5 13h5v3h-5zM9.5 7h5v3h-5zM15.5 14h5v3h-5z"
    /** Screenshot: camera inside corner brackets. */
    const val SHOT = "M3 8V5a2 2 0 0 1 2-2h3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M8 21H5a2 2 0 0 1-2-2v-3M8 9h1.5l1-1.5h3L14.5 9H16a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1zM12 10.5a2 2 0 1 0 0 4a2 2 0 1 0 0-4z"
    const val HEADPHONES = "M4 14v-2a8 8 0 0 1 16 0v2M4 14h3a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2zM20 14h-3a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h1a2 2 0 0 0 2-2z"
    /** Rotate screen: tilted square with two turning arrows. */
    const val ROTATE_SCREEN = "M12 6.8l5.2 5.2-5.2 5.2L6.8 12zM2.64 10.35A9.5 9.5 0 0 1 9.54 2.82M6.82 1.55L9.54 2.82L7.82 5.28M21.36 13.65A9.5 9.5 0 0 1 14.46 21.18M17.18 22.45L14.46 21.18L16.18 18.72"
    /** Audio track: single music note (draw filled). */
    const val NOTE = "M9 14.5a3.5 3.5 0 1 0 0 7a3.5 3.5 0 1 0 0-7zM12.5 18V4l6 2.5v3.5l-6-2"
    const val SUBTITLES = "M5 5h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zM6.5 11.5h4M13 11.5h4.5M6.5 15h7M16 15h1.5"
    const val ASPECT = "M4 6h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1zM8 9.5h8v5H8z"
    const val PIP = "M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zM12 12h6.5v4.5H12z"
    const val REPEAT = "M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3"
    const val MOON = "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/**
 * Press feedback: the view shrinks slightly while held and springs back on release.
 * The touch is never consumed, so clicks, long-clicks and scrolling keep working.
 */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable(scale: Float = 0.95f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(scale).scaleY(scale).alpha(0.88f)
                    .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(220).setInterpolator(OvershootInterpolator(2.2f)).start()
        }
        false
    }
}

/** Smoothly shows a view (also fixes up a fade-out that was still running). */
fun View.fadeIn(ms: Long = 200) {
    animate().cancel()
    if (visibility != View.VISIBLE) {
        alpha = 0f
        visibility = View.VISIBLE
    }
    animate().alpha(1f).setDuration(ms).start()
}

/** Smoothly hides a view. */
fun View.fadeOut(ms: Long = 200) {
    if (visibility != View.VISIBLE) return
    animate().cancel()
    animate().alpha(0f).setDuration(ms).withEndAction {
        visibility = View.GONE
        alpha = 1f
    }.start()
}

class PathIcon(data: String, color: Int, private val filled: Boolean, private val size: Int) : Drawable() {
    private val path: Path = PathParser.createPathFromPathData(data)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = if (filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
        strokeWidth = 1.7f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }
    override fun draw(canvas: Canvas) {
        val b = bounds
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.scale(b.width() / 24f, b.height() / 24f)
        canvas.drawPath(path, paint)
        canvas.restore()
    }
    override fun getIntrinsicWidth(): Int = size
    override fun getIntrinsicHeight(): Int = size
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun Context.iconView(path: String, color: Int = Col.TX, sizeDp: Int = 24, filled: Boolean = false): ImageView {
    val iv = ImageView(this)
    iv.setImageDrawable(PathIcon(path, color, filled, dp(sizeDp)))
    return iv
}

fun Context.tv(s: String, sp: Float = 14f, color: Int = Col.TX, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = sp
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    return t
}

/** 1px separator line. */
fun Context.hairline(): View {
    val v = View(this)
    v.setBackgroundColor(Col.LINE)
    return v
}

fun rr(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    if (strokeW > 0) g.setStroke(strokeW, strokeColor)
    return g
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val c = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, c) else String.format("%d:%02d", m, c)
}

fun fmtSize(b: Long): String =
    if (b >= 1_000_000_000L) String.format("%.2f GB", b / 1e9) else String.format("%.1f MB", b / 1e6)

fun Context.queryName(u: Uri): String {
    try {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Video"
        }
    } catch (e: Exception) {
    }
    return u.lastPathSegment ?: "Video"
}

/** Vertical slider used for brightness and volume. */
class VSlider(ctx: Context) : View(ctx) {
    var value = 0.5f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF; strokeWidth = ctx.dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Col.AC; strokeWidth = ctx.dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(c: Canvas) {
        val x = width / 2f
        val pad = height * 0.06f
        val top = pad
        val bot = height - pad
        c.drawLine(x, top, x, bot, track)
        val y = bot - (bot - top) * value
        c.drawLine(x, bot, x, y, fill)
        c.drawCircle(x, y, context.dp(7).toFloat(), thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent.requestDisallowInterceptTouchEvent(true)
        val pad = height * 0.06f
        value = 1f - ((e.y - pad) / (height - 2 * pad))
        onChange?.invoke(value)
        return true
    }
}

/** Slim horizontal seek bar: thin track, accent progress, round thumb that grows while dragging. */
class HSeek(ctx: Context) : View(ctx) {
    /** Position from 0 to 1000. */
    var progress = 0
        set(v) {
            field = v.coerceIn(0, 1000)
            invalidate()
        }
    var onStart: (() -> Unit)? = null
    var onChange: ((Int) -> Unit)? = null
    var onStop: ((Int) -> Unit)? = null
    private val pad = ctx.dp(12).toFloat()
    private var thumbR = ctx.dp(6).toFloat()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF; strokeWidth = ctx.dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Col.AC; strokeWidth = ctx.dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    /** Colour of the played part and of the round thumb. */
    fun setColors(played: Int, thumbColor: Int) {
        fill.color = played
        thumb.color = thumbColor
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val y = height / 2f
        val x1 = width - pad
        c.drawLine(pad, y, x1, y, track)
        val x = pad + (x1 - pad) * progress / 1000f
        c.drawLine(pad, y, x, y, fill)
        c.drawCircle(x, y, thumbR, thumb)
    }

    private fun grow(big: Boolean) {
        val a = ValueAnimator.ofFloat(thumbR, context.dp(if (big) 9 else 6).toFloat())
        a.duration = 140
        a.addUpdateListener {
            thumbR = it.animatedValue as Float
            invalidate()
        }
        a.start()
    }

    private fun moveTo(x: Float) {
        val w = width - 2 * pad
        if (w <= 0f) return
        progress = ((x - pad) / w * 1000f).toInt()
        onChange?.invoke(progress)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true)
                grow(true)
                onStart?.invoke()
                moveTo(e.x)
            }
            MotionEvent.ACTION_MOVE -> moveTo(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                moveTo(e.x)
                grow(false)
                onStop?.invoke(progress)
            }
        }
        return true
    }
}

private val TAG_TOKEN = Regex("(?i)^[(\\[]?(\\d{3,4}p|4k|uhd|bluray|blu-ray|brrip|bdrip|webrip|web-dl|webdl|hdrip|hdtv|dvdrip|hdcam|camrip|x264|x265|h264|h265|hevc|10bit|remux)[)\\]]?$")

/** Turns a raw file name into something readable. */
fun cleanName(raw: String): String {
    var s = raw
    val dot = s.lastIndexOf('.')
    if (dot > 0 && s.length - dot <= 5) s = s.substring(0, dot)
    if (!s.contains(' ')) s = s.replace('.', ' ').replace('_', ' ')
    val tokens = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val cut = tokens.indexOfFirst { TAG_TOKEN.matches(it) }
    val kept = if (cut > 0) tokens.subList(0, cut) else tokens
    val out = kept.joinToString(" ").trim().trimEnd('-', '(', '[', ' ')
    return if (out.isEmpty()) raw else out
}

/** Standard resolution label from pixel size (works for portrait and cropped widescreen too). */
fun qualityLabel(w: Int, h: Int): String {
    val long = maxOf(w, h)
    return when {
        long <= 0 -> ""
        long >= 3800 -> "4K"
        long >= 2500 -> "1440p"
        long >= 1900 -> "1080p"
        long >= 1250 -> "720p"
        long >= 850 -> "480p"
        long >= 600 -> "360p"
        else -> "${minOf(w, h)}p"
    }
}
